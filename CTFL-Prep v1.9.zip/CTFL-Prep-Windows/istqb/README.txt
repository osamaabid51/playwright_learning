Optional: put your own copies of the official ISTQB files here (personal use):

  syllabus.pdf    - ISTQB CTFL Syllabus v4.0.1 (free download from istqb.org)
  questions.json  - data/questions.json from the first content pack (Sample Exams A-D)

Then reload the app in the browser.
