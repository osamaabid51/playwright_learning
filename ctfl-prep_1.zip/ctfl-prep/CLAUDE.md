Read AGENTS.md — it is the complete product, content and engineering guide for this repository.
