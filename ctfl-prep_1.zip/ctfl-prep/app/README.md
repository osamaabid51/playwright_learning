# CTFL Prep – personal (localhost)

Study app for the ISTQB® CTFL v4.0 exam: lessons, notebook, cheat sheets, mock exams (practice or exam mode), results and progress.

## Run

Requires Node.js 18+. Easiest: double-click `start-windows.bat` (Windows) or `start-mac-linux.command` (Mac/Linux). Or manually:

```
npm install
npm run dev
```

The app opens at http://localhost:5173. For a production build, run `npm run build` and then `npm run preview`.

## Optional: official ISTQB content (your own copies, personal use)

Put these files in `public/istqb/` and reload:

| File | What it adds |
|---|---|
| `syllabus.pdf` | The official CTFL v4.0.1 syllabus (free from istqb.org). Every lesson gets an "Official syllabus p. X–Y" button that opens the exact pages. |
| `questions.json` | `data/questions.json` from the first content pack. Adds ISTQB Sample Exams A–D as 4 extra mocks with official rationale, and adds their questions to the random pool. |

The **Data** link (top right) shows what is loaded.

## What's inside

- 64 lessons, one per learning objective: 150–300 words, one example each, plus exam-trick cards
- 6 must-know cheat sheets, plus your own additions
- 992 original questions:
  - 192 lesson "Check yourself" questions
  - 400 in 10 fixed mocks
  - 400 in the extra pool
- Randomised mocks built on the official exam blueprint. No question repeats until that learning objective's pool is used up.
- Exam mode:
  - Fullscreen, 60 minutes (75 optional).
  - Leaving once gives a warning; leaving a second time forfeits.
  - Reloading or closing the page forfeits.
- Topic status (Weak < 70 · Average ≥ 70 · Good ≥ 85 · Strong ≥ 95), syllabus coverage, exam readiness and a weak-areas mode

All progress is stored in your browser (localStorage). Use **Data → Export progress** to back it up.

## Rebuilding content

`src/generated/*.json` is built from `../data` with `python3 scripts/build_data.py` (needs PyYAML). You only need this after editing the content files.

Independent study material, not affiliated with or endorsed by ISTQB®.
