"""Build app/src/generated/*.json from ../data (original content only).

Run from anywhere:  python3 app/scripts/build_data.py      (requires PyYAML)
Re-run after editing anything under data/.
"""
import json, glob, os, yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # app/
DATA = os.path.join(ROOT, '..', 'data')
OUT = os.path.join(ROOT, 'src', 'generated')
os.makedirs(OUT, exist_ok=True)


def fm(path):
    """Split a Markdown file with YAML front matter into (meta, body)."""
    txt = open(path, encoding='utf-8').read()
    _, meta, body = txt.split('---', 2)
    return yaml.safe_load(meta), body.strip()


syl = json.load(open(f'{DATA}/shared/syllabus.json', encoding='utf-8'))

lessons = {}
for p in glob.glob(f'{DATA}/public/lessons/*.md'):
    meta, body = fm(p)
    lessons[str(meta['code'])] = {**meta, 'code': str(meta['code']), 'body': body}

cheats = {}
for p in glob.glob(f'{DATA}/public/cheatsheets/*.md'):
    meta, body = fm(p)
    cheats[str(meta['chapter'])] = {**meta, 'body': body}

qs = []
for q in json.load(open(f'{DATA}/public/questions.json', encoding='utf-8')):
    expl = '\n'.join(f"{k}) {v}" for k, v in q['rationale'].items())
    qs.append({'id': q['id'], 'lo': q['lo'], 'k': q['k'], 'chapter': q['chapter'], 'topic': q['topic'],
               'concept': q.get('concept'), 'usage': q['usage'], 'source': 'original', 'stem': q['stem'],
               'figure': q.get('figure'), 'options': q['options'], 'selectCount': q['selectCount'],
               'correct': q['correct'], 'explanation': expl})
assert len({q['id'] for q in qs}) == len(qs), 'duplicate question ids'

tests = [{'id': m['id'], 'title': m['title'], 'kind': 'original', 'qids': m['qids']}
         for m in json.load(open(f'{DATA}/public/mocks.json', encoding='utf-8'))]
blueprints = json.load(open(f'{DATA}/public/blueprints.json', encoding='utf-8'))

for name, obj in [('syllabus', syl), ('lessons', lessons), ('cheatsheets', cheats), ('sectionNotes', {}),
                  ('questions', qs), ('tests', tests), ('blueprints', blueprints)]:
    json.dump(obj, open(f'{OUT}/{name}.json', 'w', encoding='utf-8'), ensure_ascii=False)

print(f'lessons {len(lessons)} · cheat sheets {len(cheats)} · questions {len(qs)} · mocks {len(tests)}')
