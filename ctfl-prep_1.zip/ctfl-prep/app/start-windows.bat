@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again. & pause & exit /b 1)
if not exist node_modules (echo Installing dependencies, first run only... & call npm install || (pause & exit /b 1))
echo Starting CTFL Prep at http://localhost:5173 ... (close this window to stop)
call npm run dev
pause
