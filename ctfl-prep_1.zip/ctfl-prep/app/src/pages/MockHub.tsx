import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { EXAM } from '../data'
import { buildRandomMock, buildWeakSession, isFinished, readiness, score, weakTopics } from '../logic'
import { uid, useStore, type Attempt } from '../store'
import { Chip } from '../components/ui'
import { markLive } from './Exam'

export function MockHub() {
  const { s, set, bank } = useStore()
  const nav = useNavigate()
  const [test, setTest] = useState<string>(bank.tests[0]?.id ?? 'random')
  const [mode, setMode] = useState<'practice' | 'exam'>('exam')
  const [timer, setTimer] = useState<'off' | 'up' | 'down'>('up')
  const [rules, setRules] = useState(false)
  const [extended, setExtended] = useState(false)
  const rd = readiness(s, bank)
  const weak = weakTopics(s)
  const randomTaken = s.attempts.filter(a => a.kind === 'random' && isFinished(a)).length

  const last = (testId: string) => s.attempts.filter(a => a.testId === testId && isFinished(a)).sort((a, b) => (b.endedAt ?? 0) - (a.endedAt ?? 0))[0]
  const title = test === 'random' ? `Randomised mock #${randomTaken + 1}` : bank.tests.find(t => t.id === test)?.title ?? ''

  const create = (): Attempt => {
    let qids: string[]
    let decks = s.decks
    if (test === 'random') { const r = buildRandomMock(s, bank); qids = r.qids; decks = r.decks }
    else qids = bank.tests.find(t => t.id === test)!.qids
    const a: Attempt = {
      id: uid(), testId: test, title, kind: test === 'random' ? 'random' : 'fixed', mode, qids, answers: {}, flags: [], locked: {},
      startedAt: Date.now(), limitSec: (mode === 'exam' ? (extended ? EXAM.extendedMinutes : EXAM.minutes) : EXAM.minutes) * 60,
      timerMode: mode === 'exam' ? 'down' : timer, elapsedSec: 0, resumedAt: Date.now(), status: 'active', warnings: [], current: 0,
    }
    set(p => ({ ...p, decks, recent: test === 'random' ? qids : p.recent, attempts: [...p.attempts, a] }))
    return a
  }
  const start = async () => {
    if (mode === 'practice') { const a = create(); nav(`/practice/${a.id}`); return }
    try { await document.documentElement.requestFullscreen() } catch { /* fullscreen refused – detection still applies */ }
    const a = create(); markLive(a.id); nav(`/exam/${a.id}`)
  }
  const startWeak = () => {
    const qids = buildWeakSession(s, bank)
    if (!qids.length) return
    const a: Attempt = { id: uid(), testId: 'weak', title: 'Weak areas', kind: 'weak', mode: 'practice', qids, answers: {}, flags: [], locked: {}, startedAt: Date.now(), limitSec: 0, timerMode: 'off', elapsedSec: 0, resumedAt: Date.now(), status: 'active', warnings: [], current: 0 }
    set(p => ({ ...p, attempts: [...p.attempts, a] })); nav(`/practice/${a.id}`)
  }
  const paused = s.attempts.filter(a => a.mode === 'practice' && (a.status === 'paused' || a.status === 'active'))

  return (
    <div className="page two-col">
      <div className="col-main">
        <h1 className="serif">Mock exams</h1>
        <p className="muted">Every mock follows the real exam: 40 questions · 60 min · pass at 26 (65%) · K1 8 / K2 24 / K3 8</p>
        {!bank.officialLoaded && <div className="info">Official ISTQB Sample Exams A–D are not loaded. See <a href="#/setup">Data</a> to add them.</div>}
        {paused.length > 0 && (
          <div className="card resume">
            <b>Unfinished practice</b>
            {paused.map(a => <button key={a.id} className="link" onClick={() => nav(`/practice/${a.id}`)}>{a.title} · question {a.current + 1}/{a.qids.length} → resume</button>)}
          </div>
        )}
        <div className="step">1 · CHOOSE A TEST</div>
        <div className="grid5">
          {bank.tests.map(t => {
            const l = last(t.id)
            const sc = l ? score(l, bank) : null
            return (
              <button key={t.id} className={test === t.id ? 'tile on' : 'tile'} onClick={() => setTest(t.id)}>
                <b>{t.title}</b>
                <span className={sc ? (l!.status === 'forfeited' ? 'neg small' : 'pos small') : 'muted small'}>
                  {sc ? `${l!.status === 'forfeited' ? 'Forfeited' : l!.mode === 'exam' ? 'Exam' : 'Practice'} · ${Math.round(sc.pct)}%` : 'Not taken'}
                </span>
              </button>
            )
          })}
        </div>
        <button className={test === 'random' ? 'tile wide on' : 'tile wide'} onClick={() => setTest('random')}>
          <b>Randomised mock</b>
          <span className="small muted">Fresh 40 questions on the exam blueprint · no repeated question until each LO's pool is used up · {randomTaken} taken</span>
        </button>

        <div className="step">2 · CHOOSE A MODE</div>
        <div className="grid2">
          <label className={mode === 'practice' ? 'mode on' : 'mode'}>
            <input type="radio" name="mode" checked={mode === 'practice'} onChange={() => setMode('practice')} />
            <span><b>Practice</b><br /><span className="small muted">Answer and rationale after each question · optional timer · pause and resume · notebook open</span></span>
          </label>
          <label className={mode === 'exam' ? 'mode on' : 'mode'}>
            <input type="radio" name="mode" checked={mode === 'exam'} onChange={() => setMode('exam')} />
            <span><b>Exam mode</b><br /><span className="small muted">Fullscreen · 60-min timer · no feedback until the end · leaving twice ends the exam · counts toward readiness</span></span>
          </label>
        </div>
        {mode === 'practice' && (
          <div className="row gap8 small">Timer:
            {(['off', 'up', 'down'] as const).map(m => <label key={m}><input type="radio" name="timer" checked={timer === m} onChange={() => setTimer(m)} /> {m === 'off' ? 'Off' : m === 'up' ? 'Count up' : '60-min countdown'}</label>)}
          </div>
        )}
        <div className="right"><button className="btn lg" onClick={() => (mode === 'exam' ? setRules(true) : start())}>Start {title} · {mode === 'exam' ? 'Exam mode' : 'Practice'}</button></div>
      </div>

      <aside className="col-side">
        <div className="card">
          <div className="label">EXAM READINESS</div>
          {rd ? (
            <>
              <div className="row gap8 baseline"><span className="big serif">{rd.pct}%</span><span className={`verdict v-${rd.verdict.replace(' ', '-').toLowerCase()}`}>{rd.verdict}</span></div>
              <div className="small muted">Weighted average of your last {rd.scores.length} exam-mode attempt(s): {rd.scores.map(x => `${Math.round(x)}%`).join(' · ')}</div>
            </>
          ) : <div className="small muted">Take an exam-mode mock to measure readiness.</div>}
          <div className="scale"><div style={{ flex: 65 }}>Not ready &lt; 65</div><div style={{ flex: 10 }}>65–74</div><div style={{ flex: 25 }}>Ready ≥ 75</div></div>
        </div>
        <div className="card">
          <div className="label">WEAK AREAS</div>
          {weak.length === 0 && <div className="small muted">No weak or average topics yet (a topic needs at least 3 answers).</div>}
          {weak.slice(0, 6).map(w => <div key={w.t.code} className="row between small"><span>{w.t.lo} {w.t.title}</span><Chip status={w.status} /></div>)}
          <button className="btn amber" disabled={!weak.length} onClick={startWeak}>Practise my weak areas</button>
        </div>
      </aside>

      {rules && (
        <div className="overlay dark">
          <div className="modal">
            <div className="muted small">{title} · Exam mode</div>
            <h2 className="serif">Before you start</h2>
            <div className="grid3 center">
              <div className="stat"><b>40</b><span>questions</span></div>
              <div className="stat"><b>{extended ? 75 : 60} min</b><span>time limit</span></div>
              <div className="stat"><b>26</b><span>to pass (65%)</span></div>
            </div>
            <ul>
              <li>The exam opens in fullscreen. Keep this window in focus.</li>
              <li>Leaving fullscreen or switching tab/app gives <b>one warning</b>. Leaving again <b>ends the exam</b>.</li>
              <li>Reloading or closing the page ends the exam.</li>
              <li>The timer keeps running while you are away and submits at 0:00.</li>
              <li>You can flag questions and change answers until you submit.</li>
            </ul>
            <label className="small"><input type="checkbox" checked={extended} onChange={e => setExtended(e.target.checked)} /> Extended time: 75 min (exam in a non-native language)</label>
            <div className="row between">
              <button className="btn ghost" onClick={() => setRules(false)}>Cancel</button>
              <button className="btn lg" onClick={start}>Enter fullscreen and start</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
