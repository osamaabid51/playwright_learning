import { useEffect, useState } from 'react'
import { Navigate, useNavigate, useParams } from 'react-router-dom'
import { isCorrect } from '../data'
import { fmtTime } from '../logic'
import { logAnswers, useStore, type Attempt } from '../store'
import { QuestionView, Rationale } from '../components/ui'
import { Notebook, addNote } from '../components/Notebook'

export function Practice() {
  const { id = '' } = useParams()
  const { s, set, bank } = useStore()
  const nav = useNavigate()
  const a = s.attempts.find(x => x.id === id)
  const [draft, setDraft] = useState<string[] | undefined>()
  const [now, setNow] = useState(Date.now())
  useEffect(() => { const iv = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(iv) }, [])
  // resuming a paused attempt
  useEffect(() => {
    if (a?.status === 'paused') set(p => ({ ...p, attempts: p.attempts.map(x => (x.id === a.id ? { ...x, status: 'active', resumedAt: Date.now() } : x)) }))
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [a?.id])
  useEffect(() => { setDraft(undefined) }, [a?.current])
  if (!a) return <Navigate to="/mocks" replace />
  if (!['active', 'paused'].includes(a.status)) return <Navigate to={`/results/${a.id}`} replace />

  const q = bank.byId[a.qids[a.current]]
  const locked = !!a.locked[q.id]
  const value = locked ? a.answers[q.id] : draft
  const elapsed = a.elapsedSec + (a.status === 'active' && a.resumedAt ? (now - a.resumedAt) / 1000 : 0)
  const upd = (fn: (x: Attempt) => Attempt) => set(p => ({ ...p, attempts: p.attempts.map(x => (x.id === a.id ? fn(x) : x)) }))
  const answeredN = a.qids.filter(x => a.locked[x]).length
  const rightN = a.qids.filter(x => a.locked[x] && isCorrect(bank.byId[x], a.answers[x])).length

  const check = () => {
    if (!draft) return
    const ok = isCorrect(q, draft)
    set(p => {
      const np = logAnswers(p, [{ qid: q.id, lo: q.lo, ok }], a.kind === 'weak' || a.kind === 'topic' ? 'weak' : 'practice', a.id)
      return { ...np, attempts: np.attempts.map(x => (x.id === a.id ? { ...x, answers: { ...x.answers, [q.id]: draft }, locked: { ...x.locked, [q.id]: true } } : x)) }
    })
  }
  const finish = () => {
    upd(x => ({ ...x, status: 'completed', endedAt: Date.now(), elapsedSec: elapsed }))
    nav(`/results/${a.id}`)
  }
  const pause = () => { upd(x => ({ ...x, status: 'paused', elapsedSec: elapsed, resumedAt: undefined })); nav('/mocks') }
  if (a.timerMode === 'down' && elapsed >= a.limitSec && a.status === 'active') setTimeout(finish, 0)
  const last = a.current === a.qids.length - 1
  const flagged = a.flags.includes(q.id)

  return (
    <div className="two-pane">
      <main className="main">
        <div className="row between">
          <div className="muted">{a.title} · <b className="ink">Practice</b> · Question {a.current + 1} of {a.qids.length}</div>
          <div className="row gap8 small muted">
            <span>Score so far {rightN} / {answeredN}</span>
            {a.timerMode !== 'off' && <span className="timer mono">{a.timerMode === 'up' ? `${fmtTime(elapsed)} ↑` : `${fmtTime(a.limitSec - elapsed)} left`}</span>}
            <button className="btn ghost sm" onClick={pause}>Pause</button>
          </div>
        </div>
        <div className="progress"><div style={{ width: `${(100 * answeredN) / a.qids.length}%` }} /></div>
        <QuestionView q={q} value={value} onChange={setDraft} reveal={locked} name={`pr-${q.id}`} />
        {locked && <Rationale q={q} value={a.answers[q.id]} />}
        <div className="row between">
          <div className="row gap8">
            <button className="btn ghost" disabled={a.current === 0} onClick={() => upd(x => ({ ...x, current: x.current - 1 }))}>Previous</button>
            <button className={flagged ? 'btn ghost flagged' : 'btn ghost'} onClick={() => upd(x => ({ ...x, flags: flagged ? x.flags.filter(f => f !== q.id) : [...x.flags, q.id] }))}>⚑ {flagged ? 'Flagged' : 'Flag'}</button>
          </div>
          <div className="row gap8">
            {!locked && <button className="btn" disabled={!draft || draft.length !== q.selectCount} onClick={check}>Check answer</button>}
            {locked && !last && <button className="btn" onClick={() => upd(x => ({ ...x, current: x.current + 1 }))}>Next question</button>}
            {(last && locked) || answeredN === a.qids.length ? <button className="btn" onClick={finish}>Finish & see results</button> : null}
            {!last && <button className="link small" onClick={finish}>End now</button>}
          </div>
        </div>
      </main>
      <aside className="notebook-col">
        {locked && !isCorrect(q, a.answers[q.id]) && (
          <button className="btn amber full" onClick={() => addNote(set, { topic: q.topic, kind: 'mistake', qid: q.id, text: `Missed: ${q.stem.slice(0, 110)}${q.stem.length > 110 ? '…' : ''} → answer ${q.correct.join(', ')}` })}>Save this question as a mistake</button>
        )}
        <Notebook topic={q.topic} />
      </aside>
    </div>
  )
}
