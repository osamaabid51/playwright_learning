import { useEffect, useState } from 'react'
import { lessons, topics } from '../data'
import { useStore } from '../store'

export function Setup() {
  const { bank, s, set } = useStore()
  const [pdf, setPdf] = useState<boolean | null>(null)
  useEffect(() => { fetch(`${import.meta.env.BASE_URL}istqb/syllabus.pdf`, { method: 'HEAD' }).then(r => setPdf(r.ok && (r.headers.get('content-type') ?? '').includes('pdf'))).catch(() => setPdf(false)) }, [])
  const original = bank.questions.filter(q => q.source === 'original')
  const exportData = () => {
    const blob = new Blob([JSON.stringify(s, null, 1)], { type: 'application/json' })
    const u = URL.createObjectURL(blob); const el = document.createElement('a'); el.href = u; el.download = `ctfl-progress-${new Date().toISOString().slice(0, 10)}.json`; el.click(); URL.revokeObjectURL(u)
  }
  const importData = (f: File) => f.text().then(t => { try { const d = JSON.parse(t); if (d && d.topics && d.answers) set(() => d) } catch { alert('Not a valid progress file') } })
  return (
    <div className="page narrow">
      <h1 className="serif">Data &amp; setup</h1>
      <div className="card">
        <h3>Bundled original content</h3>
        <ul>
          <li>{Object.keys(lessons).length} / {topics.length} lessons with exam-trick cards</li>
          <li>{original.length} original questions ({original.filter(q => q.usage === 'lesson').length} lesson · {original.filter(q => q.usage.startsWith('mock-')).length} in 10 fixed mocks · {original.filter(q => q.usage === 'pool').length} in the extra pool)</li>
        </ul>
      </div>
      <div className="card">
        <h3>Official ISTQB content (personal use, supplied by you)</h3>
        <p className="small muted">The app never ships ISTQB material. Put your own copies into the <code>public/istqb/</code> folder of the app, then reload.</p>
        <table className="plain">
          <tbody>
            <tr><td><code>public/istqb/syllabus.pdf</code></td><td>Official CTFL v4.0.1 syllabus (free download from istqb.org) — opens beside each lesson at the right pages</td><td>{pdf === null ? '…' : pdf ? <b className="pos">Found</b> : <b className="neg">Missing</b>}</td></tr>
            <tr><td><code>public/istqb/questions.json</code></td><td>The <code>data/questions.json</code> file from the first content pack — adds ISTQB Sample Exams A–D (with official rationale) as 4 extra mocks and to the random pool</td><td>{bank.officialLoaded ? <b className="pos">{bank.officialCount} official questions loaded</b> : <b className="neg">Missing</b>}</td></tr>
          </tbody>
        </table>
      </div>
      <div className="card">
        <h3>Your progress</h3>
        <p className="small muted">Everything (progress, notes, attempts) is stored in this browser only. Export a backup or move it to another browser.</p>
        <div className="row gap8">
          <button className="btn" onClick={exportData}>Export progress</button>
          <label className="btn ghost">Import progress<input type="file" accept="application/json" hidden onChange={e => e.target.files?.[0] && importData(e.target.files[0])} /></label>
          <button className="btn ghost danger" onClick={() => { if (confirm('Delete all progress, notes and attempts in this browser?')) set(() => ({ topics: {}, answers: [], attempts: [], decks: {}, recent: [], weak: {}, retired: [], notes: [], cheatAdds: {} })) }}>Reset everything</button>
        </div>
      </div>
      <p className="small muted">Independent study material. Not affiliated with or endorsed by ISTQB®. ISTQB® is a registered trademark of the International Software Testing Qualifications Board.</p>
    </div>
  )
}
