import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { chapters, cheatsheets, topicByCode } from '../data'
import { useStore } from '../store'
import { Md } from '../components/ui'

export function CheatSheets() {
  const { ch = '1' } = useParams()
  const { s, set } = useStore()
  const [line, setLine] = useState('')
  const c = chapters.find(x => String(x.number) === ch) ?? chapters[0]
  const sheet = cheatsheets[String(c.number)]
  const adds = s.cheatAdds[String(c.number)] ?? []
  const fromNotes = s.notes.filter(n => n.cheat && topicByCode[n.topic]?.chapter === c.number)
  const add = () => { if (!line.trim()) return; set(p => ({ ...p, cheatAdds: { ...p.cheatAdds, [c.number]: [...(p.cheatAdds[c.number] ?? []), line.trim()] } })); setLine('') }
  const remove = (i: number) => set(p => ({ ...p, cheatAdds: { ...p.cheatAdds, [c.number]: (p.cheatAdds[c.number] ?? []).filter((_, j) => j !== i) } }))
  return (
    <div className="page">
      <div className="row between no-print">
        <div className="pills">{chapters.map(x => <Link key={x.number} to={`/cheatsheets/${x.number}`} className={x.number === c.number ? 'pill on' : 'pill'}>Ch {x.number}</Link>)}</div>
        <button className="btn ghost" onClick={() => window.print()}>Print / PDF</button>
      </div>
      <div className="cheat-wrap">
        <div className="card cheat">
          <div className="row between"><h1 className="serif">Chapter {c.number} · {c.title}</h1><span className="muted">{c.examQuestions} of 40 exam questions</span></div>
          {sheet ? <div className="cheat-body"><Md>{sheet.body}</Md></div>
            : <p className="muted">The must-know sheet for this chapter is being written. Your own additions below are already saved.</p>}
        </div>
        <div className="cheat-side">
          <div className="card mine">
            <div className="label-amber">MY ADDITIONS</div>
            {fromNotes.map(n => <div key={n.id} className="mine-item">{n.text}<span className="mono small muted"> · {topicByCode[n.topic]?.lo}</span></div>)}
            {adds.map((a, i) => <div key={i} className="mine-item">{a} <button className="link no-print" onClick={() => remove(i)}>remove</button></div>)}
            {!fromNotes.length && !adds.length && <div className="muted small">Tick "On my cheat sheet" on any notebook note, or add a line here.</div>}
            <label htmlFor="add-line" className="small muted no-print">Add a line</label>
            <div className="row gap8 no-print"><input id="add-line" value={line} onChange={e => setLine(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()} /><button className="btn" onClick={add}>Add</button></div>
          </div>
          <div className="card small muted no-print">Must-know items only. Explanations and examples are in the lessons.</div>
        </div>
      </div>
    </div>
  )
}
