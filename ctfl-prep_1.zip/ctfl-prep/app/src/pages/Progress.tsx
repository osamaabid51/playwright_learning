import { Link, useNavigate } from 'react-router-dom'
import { chapters, EXAM } from '../data'
import { buildWeakSession, coverage, isFinished, loStatus, readiness, score, statusColor } from '../logic'
import { uid, useStore, type Attempt } from '../store'
import { Bar } from '../components/ui'

export function Progress() {
  const { s, set, bank } = useStore()
  const nav = useNavigate()
  const cov = coverage(s)
  const rd = readiness(s, bank)
  const done = s.attempts.filter(isFinished).sort((a, b) => (b.endedAt ?? 0) - (a.endedAt ?? 0))
  const exams = done.filter(a => a.mode === 'exam' && a.qids.length === 40).slice().reverse()
  const days = new Set(s.answers.map(a => new Date(a.ts).toDateString()))
  let streak = 0
  for (let d = new Date(); days.has(d.toDateString()); d.setDate(d.getDate() - 1)) streak++
  const weekAgo = Date.now() - 7 * 864e5
  const weekAnswers = s.answers.filter(a => a.ts > weekAgo).length

  const startWeak = () => {
    const qids = buildWeakSession(s, bank)
    if (!qids.length) return
    const a: Attempt = { id: uid(), testId: 'weak', title: 'Weak areas', kind: 'weak', mode: 'practice', qids, answers: {}, flags: [], locked: {}, startedAt: Date.now(), limitSec: 0, timerMode: 'off', elapsedSec: 0, resumedAt: Date.now(), status: 'active', warnings: [], current: 0 }
    set(p => ({ ...p, attempts: [...p.attempts, a] })); nav(`/practice/${a.id}`)
  }

  // trend chart geometry
  const W = 600, H = 150, x0 = 40, x1 = 590, y = (v: number) => 20 + (100 - v) * 1.0
  const pts = exams.map((a, i) => ({ x: exams.length === 1 ? (x0 + x1) / 2 : x0 + 20 + (i * (x1 - x0 - 40)) / (exams.length - 1), v: score(a, bank).pct, a }))

  return (
    <div className="page progress-grid">
      <div className="col">
        <div className="grid2">
          <div className="card">
            <div className="label">SYLLABUS COVERAGE</div>
            <div className="big serif">{cov.pct}%</div>
            <div className="small muted">{cov.passed} / {cov.total} topics passed</div>
            <Bar pct={cov.pct} color="var(--strong)" />
          </div>
          <div className="card">
            <div className="label">EXAM READINESS</div>
            {rd ? <><div className="row gap8 baseline"><span className="big serif">{rd.pct}%</span><span className={`verdict v-${rd.verdict.replace(' ', '-').toLowerCase()}`}>{rd.verdict}</span></div>
              <div className="small muted">Last {rd.scores.length} exam-mode attempt(s)</div><Bar pct={rd.pct} color="var(--good)" /></>
              : <div className="small muted">Take an exam-mode mock to measure readiness.</div>}
          </div>
        </div>
        <div className="card">
          <div className="row between"><b>Topic map</b><button className="btn amber sm" onClick={startWeak}>Practise my weak areas</button></div>
          {chapters.map(c => (
            <div key={c.number} className="maprow">
              <span className="maplabel">Ch{c.number}</span>
              <div className="tiles">
                {c.sections.flatMap(sec => sec.topics).map(t => {
                  const st = loStatus(s, t.lo)
                  const passed = s.topics[t.code]?.passed
                  return (
                    <Link key={t.code} to={`/learn/${t.code}`} className="tile-sm" title={`${t.lo} ${t.title} — ${st.status}${st.n ? ` (${Math.round(st.acc * 100)}%, ${st.n} answers)` : ''}${passed ? ' · lesson passed' : ''}`}
                      style={{ background: statusColor[st.status], color: st.status === 'Average' || st.status === 'Not started' ? 'var(--ink)' : '#fff', outline: passed ? '2px solid var(--ink)' : 'none' }}>
                      {t.code}
                    </Link>
                  )
                })}
              </div>
            </div>
          ))}
          <div className="legend small">
            {(['Strong', 'Good', 'Average', 'Weak', 'Not started'] as const).map(k => <span key={k}><i className="sw" style={{ background: statusColor[k] }} />{k}{k === 'Strong' ? ' ≥95%' : k === 'Good' ? ' ≥85%' : k === 'Average' ? ' ≥70%' : k === 'Weak' ? ' <70%' : ''}</span>)}
            <span><i className="sw" style={{ outline: '2px solid var(--ink)' }} />lesson passed</span>
          </div>
        </div>
      </div>
      <div className="col">
        <div className="card">
          <b>Exam-mode score trend</b>
          {pts.length === 0 ? <div className="small muted">No exam-mode attempts yet.</div> : (
            <svg viewBox={`0 0 ${W} ${H}`} className="chart" role="img" aria-label="Exam-mode scores over time">
              {[100, 60, 20].map(v => <g key={v}><line x1={x0} x2={x1} y1={y(v)} y2={y(v)} stroke="var(--line)" /><text x={x0 - 6} y={y(v) + 4} textAnchor="end" className="axis">{v}</text></g>)}
              <line x1={x0} x2={x1} y1={y(EXAM.passPercent)} y2={y(EXAM.passPercent)} stroke="var(--weak)" strokeDasharray="5 4" />
              <text x={x1} y={y(EXAM.passPercent) - 4} textAnchor="end" className="axis neg">pass 65%</text>
              {pts.length > 1 && <polyline points={pts.map(p => `${p.x},${y(p.v)}`).join(' ')} fill="none" stroke="var(--good)" strokeWidth="2.5" />}
              {pts.map((p, i) => <circle key={i} cx={p.x} cy={y(p.v)} r="5" fill={p.v >= EXAM.passPercent ? 'var(--good)' : 'var(--weak)'}><title>{p.a.title}: {Math.round(p.v)}%</title></circle>)}
            </svg>
          )}
        </div>
        <div className="card">
          <b>Attempt history</b>
          <div className="hist th"><span>DATE</span><span>TEST</span><span>MODE</span><span>SCORE</span><span>RESULT</span><span>NOTES</span></div>
          {done.length === 0 && <div className="small muted">No finished attempts yet.</div>}
          {done.slice(0, 12).map(a => {
            const sc = score(a, bank)
            const full = a.qids.length === 40
            return (
              <Link key={a.id} to={`/results/${a.id}`} className="hist">
                <span className="muted">{new Date(a.endedAt ?? a.startedAt).toLocaleDateString(undefined, { day: '2-digit', month: 'short' })}</span>
                <span>{a.title}</span><span>{a.mode === 'exam' ? 'Exam' : 'Practice'}</span>
                <span className="mono">{sc.right}/{sc.total}</span>
                <span className={!full ? 'muted' : sc.pct >= EXAM.passPercent ? 'pos' : 'neg'}>{!full ? '—' : sc.pct >= EXAM.passPercent ? 'Pass' : 'Fail'}</span>
                <span className="muted small">{a.status === 'forfeited' ? 'Forfeited' : a.status === 'timeout' ? 'Timed out' : ''}{a.warnings.length ? ` ${a.warnings.length} warning` : ''}{a.mode === 'practice' && full ? 'not counted' : ''}</span>
              </Link>
            )
          })}
          <div className="row gap16 small muted activity">
            <span>Streak <b className="ink">{streak} day{streak === 1 ? '' : 's'}</b></span>
            <span>This week <b className="ink">{weekAnswers} answers</b></span>
            <span>Notes <b className="ink">{s.notes.length}</b> · mistakes <b className="ink">{s.notes.filter(n => n.kind === 'mistake').length}</b></span>
          </div>
        </div>
      </div>
    </div>
  )
}
