import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { Link, Navigate, useParams } from 'react-router-dom'
import { chapters, isCorrect, lessons, sectionNotes, topicByCode, topics } from '../data'
import { coreCheck, coverage, moreForTopic, replacementFor } from '../logic'
import { logAnswers, useStore } from '../store'
import { Md, QuestionView, Rationale } from '../components/ui'
import { Notebook, addNote } from '../components/Notebook'
const PdfPanel = lazy(() => import('../components/PdfPanel').then(m => ({ default: m.PdfPanel })))

export function LearnIndex() {
  const { s } = useStore()
  const next = topics.find(t => !s.topics[t.code]?.passed) ?? topics[0]
  return <Navigate to={`/learn/${next.code}`} replace />
}

function Sidebar({ current }: { current: string }) {
  const { s } = useStore()
  const cur = topicByCode[current]
  return (
    <aside className="sidebar">
      <div className="side-title">SYLLABUS v4.0.1 · COVERAGE</div>
      {chapters.map(c => {
        const cov = coverage(s, c.number)
        const open = c.number === cur.chapter
        const first = c.sections[0].topics[0].code
        return (
          <div key={c.number}>
            <Link to={`/learn/${open ? current : first}`} className={open ? 'side-ch on' : 'side-ch'}>
              <span>{c.number} · {c.title}</span><span className={cov.pct === 100 ? 'pos' : ''}>{cov.pct}%</span>
            </Link>
            {open && c.sections.map(sec => (
              <div key={sec.code} className="side-sec">
                {sec.topics.length > 1 || sec.topics[0].code !== sec.code ? <div className="side-sec-t">{sec.code} {sec.title}</div> : null}
                {sec.topics.map(t => {
                  const st = s.topics[t.code]
                  const label = st?.passed ? 'Passed' : st?.understood ? 'Checking' : ''
                  return (
                    <Link key={t.code} to={`/learn/${t.code}`} className={t.code === current ? 'side-t on' : 'side-t'}>
                      <span>{t.code} {t.title}</span><span className={st?.passed ? 'pos' : 'muted'}>{label}</span>
                    </Link>
                  )
                })}
              </div>
            ))}
          </div>
        )
      })}
    </aside>
  )
}

function CheckYourself({ code }: { code: string }) {
  const { s, set, bank } = useStore()
  const st = s.topics[code]
  const chk = st?.check
  const [value, setValue] = useState<string[] | undefined>()
  const [revealed, setRevealed] = useState(false)
  useEffect(() => { setValue(undefined); setRevealed(false) }, [code, chk?.idx])
  if (!chk) return null
  const qid = chk.queue[chk.idx]
  const q = bank.byId[qid]
  const coreN = chk.queue.length
  const check = () => {
    const ok = isCorrect(q, value)
    setRevealed(true)
    set(prev => {
      let nx = logAnswers(prev, [{ qid, lo: q.lo, ok }], 'lesson', `lesson-${code}`)
      const c = nx.topics[code].check!
      let queue = c.queue
      if (!ok) {
        const rep = replacementFor(bank, q, queue)
        queue = [...queue, rep ?? qid]
      }
      nx = { ...nx, topics: { ...nx.topics, [code]: { ...nx.topics[code], check: { ...c, queue, done: { ...c.done, [qid + '#' + c.idx]: ok } } } } }
      return nx
    })
  }
  const next = () => set(prev => {
    const c = prev.topics[code].check!
    const idx = c.idx + 1
    const passed = idx >= c.queue.length
    return { ...prev, topics: { ...prev.topics, [code]: { ...prev.topics[code], passed: prev.topics[code].passed || passed, check: passed ? undefined : { ...c, idx } } } }
  })
  const results = Object.values(chk.done)
  return (
    <section className="card check">
      <div className="row between">
        <h2 className="serif">Check yourself</h2>
        <div className="row gap8 small muted">
          {chk.queue.map((_, i) => <span key={i} className="seg" style={{ background: i < chk.idx ? (results[i] ? 'var(--strong)' : 'var(--weak)') : i === chk.idx ? 'var(--good)' : 'var(--line)' }} />)}
          <span>Question {chk.idx + 1} of {coreN}</span>
        </div>
      </div>
      {chk.idx > 0 && chk.queue.length > 0 && results[chk.idx - 1] === false && !revealed && <div className="label-blue">REPLACEMENT QUESTION · SAME TOPIC</div>}
      <QuestionView q={q} value={value} onChange={setValue} reveal={revealed} name={`chk-${qid}-${chk.idx}`} />
      {revealed && <Rationale q={q} value={value} />}
      <div className="row between">
        <span className="small muted">Answer every question correctly to complete this topic. You can leave at any time.</span>
        <div className="row gap8">
          {revealed && !isCorrect(q, value) && <button className="btn ghost" onClick={() => addNote(set, { topic: code, kind: 'mistake', qid, text: `Missed: ${q.stem.slice(0, 110)}${q.stem.length > 110 ? '…' : ''} → answer ${q.correct.join(', ')}` })}>Save as mistake</button>}
          {!revealed ? <button className="btn" disabled={!value || value.length !== q.selectCount} onClick={check}>Check answer</button>
            : <button className="btn" onClick={next}>{chk.idx + 1 >= s.topics[code].check!.queue.length && isCorrect(q, value) ? 'Finish' : 'Next'}</button>}
        </div>
      </div>
    </section>
  )
}

function MorePractice({ code }: { code: string }) {
  const { s, set, bank } = useStore()
  const [qids, setQids] = useState<string[]>([])
  const [i, setI] = useState(0)
  const [value, setValue] = useState<string[] | undefined>()
  const [rev, setRev] = useState(false)
  const start = () => { setQids(moreForTopic(s, bank, code, [])); setI(0); setValue(undefined); setRev(false) }
  if (!qids.length) return (
    <div className="card passed-card">
      <div><b className="pos">✓ Topic passed.</b> <span className="muted">Confident? Move on. Want more practice on this topic?</span></div>
      <button className="btn ghost" onClick={start}>Give me more (5)</button>
    </div>
  )
  if (i >= qids.length) return <div className="card passed-card"><b>Done — {qids.length} extra questions answered.</b><button className="btn ghost" onClick={start}>5 more</button></div>
  const q = bank.byId[qids[i]]
  return (
    <section className="card check">
      <div className="row between"><h2 className="serif">More practice</h2><span className="small muted">{i + 1} / {qids.length}</span></div>
      <QuestionView q={q} value={value} onChange={setValue} reveal={rev} name={`more-${q.id}`} />
      {rev && <Rationale q={q} value={value} />}
      <div className="right">
        {!rev ? <button className="btn" disabled={!value || value.length !== q.selectCount} onClick={() => { setRev(true); set(p => logAnswers(p, [{ qid: q.id, lo: q.lo, ok: isCorrect(q, value) }], 'more', `more-${code}-${Date.now()}`)) }}>Check answer</button>
          : <button className="btn" onClick={() => { setI(i + 1); setValue(undefined); setRev(false) }}>Next</button>}
      </div>
    </section>
  )
}

export function Learn() {
  const { code = '' } = useParams()
  const { s, set, bank } = useStore()
  const [pdf, setPdf] = useState(false)
  const [showLesson, setShowLesson] = useState(false)
  const [hl, setHl] = useState<{ x: number; y: number; text: string } | null>(null)
  const art = useRef<HTMLDivElement>(null)
  useEffect(() => { setShowLesson(false); setHl(null); window.scrollTo(0, 0) }, [code])
  const t = topicByCode[code]
  if (!t) return <Navigate to="/learn" replace />
  const lesson = lessons[code]
  const st = s.topics[code] ?? {}
  const idx = topics.findIndex(x => x.code === code)
  const prev = topics[idx - 1], next = topics[idx + 1]
  const checking = st.understood && !st.passed && st.check

  const understood = () => set(p => ({ ...p, topics: { ...p.topics, [code]: { ...p.topics[code], understood: true, check: { queue: coreCheck(bank, code), done: {}, idx: 0 } } } }))
  const onMouseUp = () => {
    const sel = window.getSelection()
    const text = sel?.toString().trim() ?? ''
    if (!sel || text.length < 4 || !art.current?.contains(sel.anchorNode)) { setHl(null); return }
    const r = sel.getRangeAt(0).getBoundingClientRect()
    const box = art.current.getBoundingClientRect()
    setHl({ x: r.left - box.left + r.width / 2, y: r.top - box.top - 40, text })
  }

  const lessonBody = (
    <div ref={art} className="article" onMouseUp={onMouseUp}>
      {hl && <button className="hl-btn" style={{ left: hl.x, top: hl.y }} onMouseDown={e => e.preventDefault()} onClick={() => { addNote(set, { topic: code, kind: 'highlight', text: hl.text }); setHl(null); window.getSelection()?.removeAllRanges() }}>+ Add to notebook</button>}
      {lesson ? <Md>{lesson.body}</Md> : (
        <>
          <div className="draft-note">Concise lesson for this topic is being written. Showing our section study notes ({t.section}) meanwhile.</div>
          <Md>{(sectionNotes[t.section] ?? '').replace(/^### [^\n]*\n/, '')}</Md>
        </>
      )}
      {lesson?.trick && (
        <div className="trick">
          <div className="label-amber">EXAM TRICK</div>
          <div><b>Rule:</b> {lesson.trick.rule}</div>
          <div><b>Trap:</b> {lesson.trick.trap}</div>
          {lesson.trick.check && <div><b>Check:</b> {lesson.trick.check}</div>}
        </div>
      )}
    </div>
  )

  return (
    <div className="three">
      <Sidebar current={code} />
      <main className="main">
        <div className="crumbs">
          <span>Chapter {t.chapter}</span><span>/</span><span>{t.section} {t.sectionTitle}</span>
          <span className="mono badge">{t.lo} · {t.k}</span>
          {lesson && <span className="badge">{lesson.readMinutes} min read</span>}
          <span className="grow" />
          <button className="btn ghost sm" onClick={() => setPdf(true)}>Official syllabus p. {t.pdfPages[0]}{t.pdfPages[1] !== t.pdfPages[0] ? `–${t.pdfPages[1]}` : ''}</button>
        </div>
        <h1 className="serif">{t.title}</h1>

        {checking ? (
          <>
            <div className="card row between collapsed">
              <span><b className="pos">✓</b> <b>{t.title}</b> <span className="muted">· marked Understood</span></span>
              <button className="link" onClick={() => setShowLesson(v => !v)}>{showLesson ? 'Hide lesson' : 'Show lesson'}</button>
            </div>
            {showLesson && lessonBody}
            <CheckYourself code={code} />
          </>
        ) : (
          <>
            {lessonBody}
            {st.passed ? <MorePractice code={code} /> : (
              <div className="row between foot">
                {prev ? <Link to={`/learn/${prev.code}`}>← {prev.title}</Link> : <span />}
                <button className="btn lg" onClick={understood}>✓ Understood — check yourself</button>
              </div>
            )}
          </>
        )}
        {(st.passed || checking) && (
          <div className="row between foot">
            {prev ? <Link to={`/learn/${prev.code}`}>← {prev.title}</Link> : <span />}
            {next && <Link to={`/learn/${next.code}`}>{st.passed ? 'Next topic' : 'Skip for now'}: {next.title} →</Link>}
          </div>
        )}
      </main>
      <Notebook topic={code} />
      {pdf && <Suspense fallback={null}><PdfPanel pages={t.pdfPages} title={`${t.code} ${t.title}`} onClose={() => setPdf(false)} /></Suspense>}
    </div>
  )
}
