import { useState } from 'react'
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom'
import { chapters, EXAM, isCorrect, sourceLabel, topicByCode } from '../data'
import { buildWeakSession, fmtTime, loStatus, score } from '../logic'
import { uid, useStore, type Attempt } from '../store'
import { Chip, QuestionView, Rationale } from '../components/ui'

export function startTopicPractice(code: string, s: ReturnType<typeof useStore>['s'], set: ReturnType<typeof useStore>['set'], bank: ReturnType<typeof useStore>['bank']) {
  const qids = buildWeakSession(s, bank, code, 6)
  if (!qids.length) return null
  const a: Attempt = { id: uid(), testId: `topic-${code}`, title: `Practise ${code} ${topicByCode[code].title}`, kind: 'topic', mode: 'practice', qids, answers: {}, flags: [], locked: {}, startedAt: Date.now(), limitSec: 0, timerMode: 'off', elapsedSec: 0, resumedAt: Date.now(), status: 'active', warnings: [], current: 0 }
  set(p => ({ ...p, attempts: [...p.attempts, a] }))
  return a.id
}

export function Results() {
  const { id = '' } = useParams()
  const { s, set, bank } = useStore()
  const nav = useNavigate()
  const [open, setOpen] = useState<number | null>(null)
  const a = s.attempts.find(x => x.id === id)
  if (!a) return <Navigate to="/mocks" replace />
  const sc = score(a, bank)
  const full = a.qids.length === 40
  const passed = sc.pct >= EXAM.passPercent
  const qs = a.qids.map(x => bank.byId[x])
  const kRow = (k: string) => { const l = qs.filter(q => q.k === k); return `${l.filter(q => isCorrect(q, a.answers[q.id])).length}/${l.length}` }
  const dur = a.mode === 'exam' ? ((a.endedAt ?? Date.now()) - a.startedAt) / 1000 : a.elapsedSec
  const practise = (code: string) => { const nid = startTopicPractice(code, s, set, bank); if (nid) nav(`/practice/${nid}`) }

  const byCh = chapters.map(c => {
    const cq = qs.filter(q => q.chapter === c.number)
    const los = [...new Set(cq.map(q => q.lo))].map(lo => {
      const l = cq.filter(q => q.lo === lo)
      return { lo, code: l[0].topic, right: l.filter(q => isCorrect(q, a.answers[q.id])).length, n: l.length, st: loStatus(s, lo) }
    }).sort((x, y) => x.lo.localeCompare(y.lo, undefined, { numeric: true }))
    const right = cq.filter(q => isCorrect(q, a.answers[q.id])).length
    const pct = cq.length ? right / cq.length : 1
    const weakest = los.reduce((w, l) => (['Weak', 'Average'].includes(l.st.status) ? w + 1 : w), 0)
    return { c, right, n: cq.length, pct, los, weakest }
  }).filter(x => x.n > 0)
  const focus = byCh.filter(x => x.pct < 0.7).map(x => x.c.title)

  return (
    <div className="page results-grid">
      <div className="col-side">
        <div className="card">
          <div className="muted small">{a.title} · {a.mode === 'exam' ? 'Exam mode' : 'Practice'} · {fmtTime(dur)}</div>
          <div className="row gap8 baseline"><span className="huge serif">{sc.right}</span><span className="muted">/ {sc.total} · {Math.round(sc.pct * 10) / 10}%</span></div>
          <div className="row gap8 wrap">
            {full && <span className={passed ? 'pill-ok' : 'pill-bad'}>{passed ? 'Passed' : 'Not passed'} · pass mark 26</span>}
            {a.status === 'forfeited' && <span className="pill-bad">Forfeited</span>}
            {a.status === 'timeout' && <span className="pill-warn">Time ran out</span>}
            {a.warnings.map((w, i) => <span key={i} className="pill-warn">Warning at {fmtTime(w.atSec)} ({w.type === 'tab' ? 'left window' : 'left fullscreen'})</span>)}
          </div>
        </div>
        <div className="card grid3 center">
          <div><div className="small muted">K1 recall</div><b className="mid">{kRow('K1')}</b></div>
          <div><div className="small muted">K2 understand</div><b className="mid">{kRow('K2')}</b></div>
          <div><div className="small muted">K3 apply</div><b className="mid">{kRow('K3')}</b></div>
        </div>
        {focus.length > 0 && (
          <div className="card blue">
            <div>Focus next: <b>{focus.join(', ')}</b> — below 70% in this test.</div>
            <button className="btn white" onClick={() => nav('/mocks')}>Practise my weak areas</button>
          </div>
        )}
        <Link to={`/review/${a.id}`}>Review all {a.qids.length} questions with rationale →</Link>
      </div>

      <div className="col-main card">
        <div className="row between"><h2 className="serif">Feedback by topic</h2>
          <div className="small muted legend-st">Status uses your full history: <Chip status="Strong" /> ≥95 <Chip status="Good" /> ≥85 <Chip status="Average" /> ≥70 <Chip status="Weak" /> &lt;70</div></div>
        <div className="tbl">
          <div className="tr th"><span>TOPIC</span><span>THIS TEST</span><span>STATUS</span><span /></div>
          {byCh.map(x => (
            <div key={x.c.number}>
              <button className="tr ch" onClick={() => setOpen(open === x.c.number ? null : x.c.number)}>
                <span><b>{x.c.number} · {x.c.title}</b> <span className="muted small">{open === x.c.number ? '▾' : '▸'} {x.los.length} topics</span></span>
                <span className="mono">{x.right}/{x.n}</span>
                <span>{x.pct >= 0.95 ? <Chip status="Strong" /> : x.pct >= 0.85 ? <Chip status="Good" /> : x.pct >= 0.7 ? <Chip status="Average" /> : <Chip status="Weak" />}</span>
                <span className="small muted">{x.weakest ? `${x.weakest} topic(s) need work` : ''}</span>
              </button>
              {(open === x.c.number || x.pct < 0.7) && x.los.map(l => (
                <div key={l.lo} className="tr sub">
                  <span>{l.lo} {topicByCode[l.code]?.title}</span>
                  <span className="mono">{l.right}/{l.n}</span>
                  <span><Chip status={l.st.status} /></span>
                  <span className="small">{l.right < l.n || ['Weak', 'Average'].includes(l.st.status) ? <><Link to={`/learn/${l.code}`}>Revise lesson</Link> · <button className="link" onClick={() => practise(l.code)}>Practise</button></> : ''}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function Review() {
  const { id = '' } = useParams()
  const { s, bank } = useStore()
  const [f, setF] = useState<'wrong' | 'flagged' | 'all'>('wrong')
  const a = s.attempts.find(x => x.id === id)
  if (!a) return <Navigate to="/mocks" replace />
  const list = a.qids.map((x, i) => ({ q: bank.byId[x], i })).filter(({ q }) =>
    f === 'all' ? true : f === 'flagged' ? a.flags.includes(q.id) : !isCorrect(q, a.answers[q.id]))
  const wrongN = a.qids.filter(x => !isCorrect(bank.byId[x], a.answers[x])).length
  return (
    <div className="page narrow">
      <div className="row between"><h1 className="serif">Review · {a.title}</h1><Link to={`/results/${a.id}`}>← Results</Link></div>
      <div className="pills">
        <button className={f === 'wrong' ? 'pill on' : 'pill'} onClick={() => setF('wrong')}>Wrong ({wrongN})</button>
        <button className={f === 'flagged' ? 'pill on' : 'pill'} onClick={() => setF('flagged')}>Flagged ({a.flags.length})</button>
        <button className={f === 'all' ? 'pill on' : 'pill'} onClick={() => setF('all')}>All ({a.qids.length})</button>
      </div>
      {list.length === 0 && <div className="card muted">Nothing here.</div>}
      {list.map(({ q, i }) => (
        <div key={q.id} className="card">
          <div className="row between small muted"><span className="mono">Q{i + 1} · {q.lo} · {q.k}</span><span>{sourceLabel(q)}{!a.answers[q.id]?.length ? ' · not answered' : ''}</span></div>
          <QuestionView q={q} value={a.answers[q.id]} reveal name={`rv-${q.id}`} />
          <Rationale q={q} value={a.answers[q.id]} />
          <Link className="small" to={`/learn/${q.topic}`}>Revise lesson {q.topic} →</Link>
        </div>
      ))}
    </div>
  )
}
