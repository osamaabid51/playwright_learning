import { useCallback, useEffect, useRef, useState } from 'react'
import { Navigate, useNavigate, useParams } from 'react-router-dom'
import { isCorrect } from '../data'
import { fmtTime } from '../logic'
import { logAnswers, useStore, type Attempt } from '../store'
import { QuestionView } from '../components/ui'

let liveExamId: string | null = null
export const markLive = (id: string) => { liveExamId = id }

export function Exam() {
  const { id = '' } = useParams()
  const { s, set, bank } = useStore()
  const nav = useNavigate()
  const a = s.attempts.find(x => x.id === id)
  const aRef = useRef<Attempt | undefined>(a)
  aRef.current = a
  const done = useRef(false)
  const lastViolation = useRef(0)
  const [warn, setWarn] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const [now, setNow] = useState(Date.now())

  const finish = useCallback((status: Attempt['status']) => {
    const cur = aRef.current
    if (!cur || done.current) return
    done.current = true
    liveExamId = null
    set(p => {
      const entries = cur.qids.map(q => ({ qid: q, lo: bank.byId[q].lo, ok: isCorrect(bank.byId[q], cur.answers[q]) }))
      const np = logAnswers(p, entries, 'exam', cur.id)
      return { ...np, attempts: np.attempts.map(x => (x.id === cur.id ? { ...x, status, endedAt: Date.now() } : x)) }
    })
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {})
    nav(`/results/${cur.id}`, { replace: true })
  }, [bank, nav, set])

  const violation = useCallback((type: 'fullscreen' | 'tab') => {
    const cur = aRef.current
    if (!cur || done.current || cur.status !== 'active') return
    const t = Date.now()
    if (t - lastViolation.current < 2000) return // one exit can fire both events
    lastViolation.current = t
    if (cur.warnings.length >= 1) { finish('forfeited'); return }
    const atSec = Math.round((t - cur.startedAt) / 1000)
    set(p => ({ ...p, attempts: p.attempts.map(x => (x.id === cur.id ? { ...x, warnings: [...x.warnings, { atSec, type }] } : x)) }))
    setWarn(true)
  }, [finish, set])

  // closing / reloading = forfeit: an exam not started in this page session is ended immediately
  useEffect(() => {
    if (a && a.status === 'active' && liveExamId !== a.id) finish('forfeited')
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const onFs = () => { if (!document.fullscreenElement) violation('fullscreen') }
    const onVis = () => { if (document.visibilityState === 'hidden') violation('tab') }
    const onBlur = () => violation('tab')
    const onUnload = (e: BeforeUnloadEvent) => { if (!done.current) { e.preventDefault() } }
    document.addEventListener('fullscreenchange', onFs)
    document.addEventListener('visibilitychange', onVis)
    window.addEventListener('blur', onBlur)
    window.addEventListener('beforeunload', onUnload)
    const iv = setInterval(() => setNow(Date.now()), 500)
    return () => {
      document.removeEventListener('fullscreenchange', onFs); document.removeEventListener('visibilitychange', onVis)
      window.removeEventListener('blur', onBlur); window.removeEventListener('beforeunload', onUnload); clearInterval(iv)
    }
  }, [violation])

  const remaining = a ? a.limitSec - (now - a.startedAt) / 1000 : 0
  useEffect(() => { if (a && a.status === 'active' && remaining <= 0) finish('timeout') }, [remaining, a, finish])

  if (!a) return <Navigate to="/mocks" replace />
  if (a.status !== 'active') return <Navigate to={`/results/${a.id}`} replace />
  const q = bank.byId[a.qids[a.current]]
  const upd = (patch: Partial<Attempt>) => set(p => ({ ...p, attempts: p.attempts.map(x => (x.id === a.id ? { ...x, ...patch } : x)) }))
  const answered = a.qids.filter(x => a.answers[x]?.length).length
  const flagged = a.flags.includes(q.id)

  return (
    <div className="exam">
      <header className="exam-top">
        <div className="brand light">CTFL Prep</div>
        <div className="muted-light">{a.title} · Exam mode</div>
        <div className="grow" />
        <div className={a.warnings.length ? 'warn-light' : 'muted-light'}>Warnings {a.warnings.length} / 1</div>
        <div className="muted-light">Answered {answered} / 40</div>
        <div className={remaining < 300 ? 'clock low' : 'clock'}>{fmtTime(remaining)}</div>
        <button className="btn white" onClick={() => setConfirm(true)}>Submit exam</button>
      </header>
      <div className="exam-body">
        <main className="exam-main">
          <div className="row between"><span className="muted">Question {a.current + 1} of 40 · 1 point</span>
            <button className={flagged ? 'btn ghost flagged' : 'btn ghost'} onClick={() => upd({ flags: flagged ? a.flags.filter(f => f !== q.id) : [...a.flags, q.id] })}>⚑ {flagged ? 'Flagged' : 'Flag for review'}</button>
          </div>
          <QuestionView q={q} value={a.answers[q.id]} onChange={v => upd({ answers: { ...a.answers, [q.id]: v } })} name={`ex-${q.id}`} />
          <div className="muted small">Answers and rationale appear only after you submit.</div>
          <div className="row between exam-nav">
            <button className="btn ghost" disabled={a.current === 0} onClick={() => upd({ current: a.current - 1 })}>Previous</button>
            <button className="btn" disabled={a.current === 39} onClick={() => upd({ current: a.current + 1 })}>Next question</button>
          </div>
        </main>
        <aside className="exam-map">
          <b>Question map</b>
          <div className="map">
            {a.qids.map((x, i) => (
              <button key={x} onClick={() => upd({ current: i })}
                className={['cell', a.answers[x]?.length ? 'ans' : '', a.flags.includes(x) ? 'flag' : '', i === a.current ? 'cur' : ''].join(' ')}>{i + 1}</button>
            ))}
          </div>
          <div className="legend small"><span><i className="sw ans" />Answered</span><span><i className="sw flag" />Flagged</span><span><i className="sw cur" />Current</span></div>
          <div className="card small muted">40 questions · pass at 26 (65%) · no negative marking</div>
        </aside>
      </div>

      {warn && (
        <div className="overlay dark">
          <div className="modal">
            <h2 className="serif neg">You left the exam window</h2>
            <p>This is your only warning. If you leave fullscreen or switch tab/app again, the exam ends and is scored on the questions you have answered.</p>
            <div className="card small muted">Warning logged at {fmtTime(a.warnings[0]?.atSec ?? 0)} · the timer kept running</div>
            <div className="right"><button className="btn lg" onClick={async () => { try { await document.documentElement.requestFullscreen() } catch { /* ignore */ } lastViolation.current = Date.now(); setWarn(false) }}>Return to fullscreen</button></div>
          </div>
        </div>
      )}
      {confirm && (
        <div className="overlay">
          <div className="modal">
            <h2 className="serif">Submit the exam?</h2>
            <p>{40 - answered > 0 ? `${40 - answered} question(s) unanswered — they will count as wrong.` : 'All questions answered.'} {a.flags.length ? `${a.flags.length} flagged.` : ''}</p>
            <div className="row between"><button className="btn ghost" onClick={() => setConfirm(false)}>Back to exam</button><button className="btn" onClick={() => finish('completed')}>Submit</button></div>
          </div>
        </div>
      )}
    </div>
  )
}
