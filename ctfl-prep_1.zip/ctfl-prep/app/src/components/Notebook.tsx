import { useState } from 'react'
import { topicByCode } from '../data'
import { uid, useStore, type Note } from '../store'

export function addNote(set: ReturnType<typeof useStore>['set'], n: Omit<Note, 'id' | 'ts' | 'cheat'> & { cheat?: boolean }) {
  set(s => ({ ...s, notes: [...s.notes, { cheat: false, ...n, id: uid(), ts: Date.now() }] }))
}

export function Notebook({ topic }: { topic?: string }) {
  const { s, set } = useStore()
  const [filter, setFilter] = useState<'topic' | 'chapter' | 'mistakes' | 'all'>(topic ? 'topic' : 'all')
  const [text, setText] = useState('')
  const ch = topic ? topicByCode[topic]?.chapter : undefined
  const list = s.notes.filter(n =>
    filter === 'all' ? true : filter === 'mistakes' ? n.kind === 'mistake' : filter === 'topic' ? n.topic === topic : topicByCode[n.topic]?.chapter === ch,
  ).slice().reverse()
  const toggleCheat = (id: string) => set(st => ({ ...st, notes: st.notes.map(n => (n.id === id ? { ...n, cheat: !n.cheat } : n)) }))
  const del = (id: string) => set(st => ({ ...st, notes: st.notes.filter(n => n.id !== id) }))
  return (
    <aside className="notebook">
      <div className="nb-head"><h3>My notebook</h3><span className="muted small">{s.notes.length} notes</span></div>
      <div className="pills">
        {topic && <button className={filter === 'topic' ? 'pill on' : 'pill'} onClick={() => setFilter('topic')}>This topic</button>}
        {topic && <button className={filter === 'chapter' ? 'pill on' : 'pill'} onClick={() => setFilter('chapter')}>Chapter {ch}</button>}
        <button className={filter === 'mistakes' ? 'pill on' : 'pill'} onClick={() => setFilter('mistakes')}>Mistakes</button>
        <button className={filter === 'all' ? 'pill on' : 'pill'} onClick={() => setFilter('all')}>All</button>
      </div>
      <div className="nb-list">
        {list.length === 0 && <div className="muted small">No notes here yet. Select text in a lesson to highlight it, or write a note below.</div>}
        {list.map(n => (
          <div key={n.id} className="note">
            <div className={`note-meta ${n.kind}`}>{topicByCode[n.topic]?.lo ?? n.topic} · {n.kind}{n.qid ? ` · ${n.qid}` : ''}</div>
            <div className={n.kind === 'highlight' ? 'note-text hl' : 'note-text'}>{n.text}</div>
            <div className="note-actions">
              <label><input type="checkbox" checked={n.cheat} onChange={() => toggleCheat(n.id)} /> On my cheat sheet</label>
              <button className="link" onClick={() => del(n.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      {topic && (
        <div className="nb-new">
          <label htmlFor="nb-text" className="small muted">New note on this topic</label>
          <textarea id="nb-text" value={text} onChange={e => setText(e.target.value)} />
          <div className="right"><button className="btn" disabled={!text.trim()} onClick={() => { addNote(set, { topic, kind: 'note', text: text.trim() }); setText('') }}>Save note</button></div>
        </div>
      )}
    </aside>
  )
}
