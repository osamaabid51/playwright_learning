import { useEffect, useRef, useState } from 'react'
import * as pdfjs from 'pdfjs-dist'
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url'

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl
let docPromise: Promise<pdfjs.PDFDocumentProxy> | null = null
const getDoc = () => (docPromise ??= pdfjs.getDocument({ url: `${import.meta.env.BASE_URL}istqb/syllabus.pdf` }).promise.catch(e => { docPromise = null; throw e }))

export function PdfPanel({ pages, title, onClose }: { pages: [number, number]; title: string; onClose: () => void }) {
  const box = useRef<HTMLDivElement>(null)
  const [err, setErr] = useState(false)
  useEffect(() => {
    let cancelled = false
    const el = box.current
    if (!el) return
    el.innerHTML = ''
    getDoc().then(async doc => {
      for (let p = pages[0]; p <= pages[1] && !cancelled; p++) {
        const page = await doc.getPage(p)
        const vp = page.getViewport({ scale: 1.25 })
        const c = document.createElement('canvas')
        c.width = vp.width; c.height = vp.height
        el.appendChild(c)
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        await page.render({ canvas: c, canvasContext: c.getContext('2d')!, viewport: vp } as any).promise
      }
    }).catch(() => !cancelled && setErr(true))
    return () => { cancelled = true }
  }, [pages])
  return (
    <div className="pdf-drawer">
      <div className="pdf-head">
        <div><b>Official syllabus</b> <span className="muted">· {title} · p. {pages[0]}{pages[1] !== pages[0] ? `–${pages[1]}` : ''}</span></div>
        <button className="btn ghost" onClick={onClose}>Close</button>
      </div>
      {err ? (
        <div className="pdf-missing">
          <p><b>Syllabus PDF not found.</b></p>
          <p>Download the free <i>ISTQB CTFL Syllabus v4.0.1</i> PDF from istqb.org and save it as <code>public/istqb/syllabus.pdf</code> in the app folder, then reload.</p>
        </div>
      ) : <div className="pdf-pages" ref={box} />}
    </div>
  )
}
