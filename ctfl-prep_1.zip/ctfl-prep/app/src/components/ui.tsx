import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import remarkBreaks from 'remark-breaks'
import { NavLink, Outlet, useLocation } from 'react-router-dom'
import { coverage, readiness, statusColor, type Status } from '../logic'
import { useStore } from '../store'
import type { Question } from '../data'
import { isCorrect } from '../data'

export function Md({ children, breaks }: { children: string; breaks?: boolean }) {
  return <div className="md"><ReactMarkdown remarkPlugins={breaks ? [remarkGfm, remarkBreaks] : [remarkGfm]}>{children}</ReactMarkdown></div>
}

export function Chip({ status }: { status: Status }) {
  return <span className={`chip chip-${status.replace(' ', '-').toLowerCase()}`}>{status}</span>
}
export function Dot({ status }: { status: Status }) {
  return <span className="dot" style={{ background: statusColor[status] }} />
}

export function Bar({ pct, color }: { pct: number; color: string }) {
  return <div className="bar"><div style={{ width: `${Math.min(100, Math.max(0, pct))}%`, background: color }} /></div>
}

export function Layout() {
  const { s, bank } = useStore()
  const loc = useLocation().pathname
  const examArea = /^\/(mocks|practice|results|review|weak)/.test(loc)
  const learnArea = /^\/(learn|cheatsheets)/.test(loc) || loc === '/'
  const cov = coverage(s)
  const rd = readiness(s, bank)
  return (
    <div className="app">
      <header className="top">
        <div className="brand">CTFL Prep <span className="tag">personal</span></div>
        <nav>
          <NavLink to="/learn">Learn</NavLink>
          <NavLink to="/cheatsheets">Cheat sheets</NavLink>
          <NavLink to="/mocks">Mock exams</NavLink>
          <NavLink to="/progress">My progress</NavLink>
        </nav>
        <div className="grow" />
        {learnArea && (
          <div className="metric"><span>Syllabus coverage</span><Bar pct={cov.pct} color="var(--strong)" /><b>{cov.pct}% · {cov.passed} / {cov.total} topics</b></div>
        )}
        {examArea && (
          rd ? <div className="metric"><span>Exam readiness</span><Bar pct={rd.pct} color="var(--good)" /><b>{rd.pct}%</b><span className={`verdict v-${rd.verdict.replace(' ', '-').toLowerCase()}`}>{rd.verdict}</span></div>
            : <div className="metric muted">Exam readiness: take an exam-mode mock to measure</div>
        )}
        <NavLink to="/setup" className="small-link">Data</NavLink>
      </header>
      <Outlet />
    </div>
  )
}

/** Renders one question; `reveal` shows correct/incorrect marking. */
export function QuestionView({ q, value, onChange, reveal, name }: { q: Question; value: string[] | undefined; onChange?: (v: string[]) => void; reveal?: boolean; name: string }) {
  const multi = q.selectCount > 1
  const toggle = (k: string) => {
    if (!onChange || reveal) return
    if (!multi) return onChange([k])
    const cur = value ?? []
    onChange(cur.includes(k) ? cur.filter(x => x !== k) : cur.length < q.selectCount ? [...cur, k] : cur)
  }
  return (
    <div className="question">
      <Md breaks>{q.stem}</Md>
      {q.figure && <div className="figure"><b>Figure (text description):</b> {q.figure}</div>}
      <div className="options">
        {Object.entries(q.options).map(([k, v]) => {
          const chosen = value?.includes(k)
          const cls = reveal ? (q.correct.includes(k) ? 'opt right' : chosen ? 'opt wrong' : 'opt') : chosen ? 'opt sel' : 'opt'
          return (
            <label key={k} className={cls}>
              <input type={multi ? 'checkbox' : 'radio'} name={name} checked={!!chosen} onChange={() => toggle(k)} disabled={reveal} />
              <span className="ok">{k})</span><span className="otext">{v}</span>
              {reveal && q.correct.includes(k) && <span className="tagr">Correct</span>}
              {reveal && chosen && !q.correct.includes(k) && <span className="tagw">Your answer</span>}
            </label>
          )
        })}
      </div>
      <div className="hint">{multi ? `Select ${q.selectCount === 2 ? 'TWO' : q.selectCount} options.` : 'Select ONE option.'}</div>
    </div>
  )
}

export function Rationale({ q, value }: { q: Question; value?: string[] }) {
  const ok = isCorrect(q, value)
  return (
    <div className={`rationale ${ok ? 'r-ok' : 'r-bad'}`}>
      <div className="r-head">{ok ? 'Correct' : `Incorrect — answer: ${q.correct.join(', ')}`} <span className="mono">{q.lo} · {q.k}</span></div>
      {q.explanation.split('\n').filter(Boolean).map((l, i) => <p key={i}>{l}</p>)}
    </div>
  )
}
