import { HashRouter, Navigate, Route, Routes } from 'react-router-dom'
import { Layout } from './components/ui'
import { Learn, LearnIndex } from './pages/Learn'
import { CheatSheets } from './pages/CheatSheets'
import { MockHub } from './pages/MockHub'
import { Exam } from './pages/Exam'
import { Practice } from './pages/Practice'
import { Results, Review } from './pages/Results'
import { Progress } from './pages/Progress'
import { Setup } from './pages/Setup'

export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/exam/:id" element={<Exam />} />
        <Route element={<Layout />}>
          <Route path="/" element={<Navigate to="/learn" replace />} />
          <Route path="/learn" element={<LearnIndex />} />
          <Route path="/learn/:code" element={<Learn />} />
          <Route path="/cheatsheets" element={<CheatSheets />} />
          <Route path="/cheatsheets/:ch" element={<CheatSheets />} />
          <Route path="/mocks" element={<MockHub />} />
          <Route path="/practice/:id" element={<Practice />} />
          <Route path="/results/:id" element={<Results />} />
          <Route path="/review/:id" element={<Review />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/setup" element={<Setup />} />
          <Route path="*" element={<Navigate to="/learn" replace />} />
        </Route>
      </Routes>
    </HashRouter>
  )
}
