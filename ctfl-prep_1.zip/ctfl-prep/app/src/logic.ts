import { blueprints, chapters, EXAM, isCorrect, topics, topicByCode, type Bank, type Question } from './data'
import type { Attempt, State } from './store'

/* ---------- topic status (Weak / Average / Good / Strong) ---------- */
export type Status = 'Strong' | 'Good' | 'Average' | 'Weak' | 'Not started'
export function loStatus(s: State, lo: string): { status: Status; acc: number; n: number } {
  const a = s.answers.filter(x => x.lo === lo).slice(-10)
  if (a.length < 3) return { status: 'Not started', acc: a.length ? a.filter(x => x.ok).length / a.length : 0, n: a.length }
  let w = 0, t = 0
  a.forEach((x, i) => { const wt = i + 1; t += wt; if (x.ok) w += wt })
  const acc = w / t
  const status: Status = acc >= 0.95 ? 'Strong' : acc >= 0.85 ? 'Good' : acc >= 0.7 ? 'Average' : 'Weak'
  return { status, acc, n: a.length }
}

/* ---------- syllabus coverage (topics passed, weighted by study time) ---------- */
export function topicWeight(code: string) {
  const ch = chapters.find(c => c.number === topicByCode[code].chapter)!
  const n = ch.sections.reduce((k, s) => k + s.topics.length, 0)
  return ch.minutes / n
}
export function coverage(s: State, chapter?: number) {
  const list = topics.filter(t => chapter === undefined || t.chapter === chapter)
  const total = list.reduce((k, t) => k + topicWeight(t.code), 0)
  const done = list.filter(t => s.topics[t.code]?.passed).reduce((k, t) => k + topicWeight(t.code), 0)
  return { pct: total ? Math.round((100 * done) / total) : 0, passed: list.filter(t => s.topics[t.code]?.passed).length, total: list.length }
}

/* ---------- scoring & readiness ---------- */
export function score(a: Attempt, bank: Bank) {
  const right = a.qids.filter(id => isCorrect(bank.byId[id], a.answers[id])).length
  return { right, total: a.qids.length, pct: a.qids.length ? (100 * right) / a.qids.length : 0 }
}
export const isFinished = (a: Attempt) => ['completed', 'forfeited', 'timeout'].includes(a.status)
export function readiness(s: State, bank: Bank) {
  const ex = s.attempts.filter(a => a.mode === 'exam' && isFinished(a) && a.qids.length === 40)
    .sort((a, b) => (b.endedAt ?? 0) - (a.endedAt ?? 0)).slice(0, 3)
  if (!ex.length) return null
  const ws = [3, 2, 1].slice(0, ex.length)
  const pct = ex.reduce((k, a, i) => k + score(a, bank).pct * ws[i], 0) / ws.reduce((k, w) => k + w, 0)
  const verdict = pct >= 75 ? 'Ready' : pct >= EXAM.passPercent ? 'Borderline' : 'Not ready'
  return { pct: Math.round(pct), verdict, scores: ex.map(a => score(a, bank).pct) }
}

/* ---------- helpers ---------- */
export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]] }
  return a
}
const conceptOf = (q: Question) => q.concept ?? q.id

/* ---------- randomised mock: blueprint slots + per-LO deck (no repeats until exhausted) ---------- */
export function buildRandomMock(s: State, bank: Bank): { qids: string[]; decks: State['decks'] } {
  const bp = blueprints[Math.floor(Math.random() * blueprints.length)]
  const decks = { ...s.decks }
  const chosen: string[] = []
  const concepts = new Set<string>()
  const eligibleBase = bank.questions.filter(q => q.usage !== 'lesson')
  for (const slot of bp.slots) {
    const cands = eligibleBase.filter(q => q.lo === slot.lo)
    const ok = (id: string) => !chosen.includes(id) && !concepts.has(conceptOf(bank.byId[id]))
    let deck = (decks[slot.lo] ?? []).filter(id => bank.byId[id] && cands.some(c => c.id === id))
    if (!deck.some(ok)) {
      const fresh = shuffle(cands.map(c => c.id))
      deck = [...deck, ...fresh.filter(id => !s.recent.includes(id)), ...fresh.filter(id => s.recent.includes(id))]
    }
    const pick = deck.find(ok) ?? cands.map(c => c.id).find(ok)
    if (pick) { chosen.push(pick); concepts.add(conceptOf(bank.byId[pick])); deck = deck.filter(id => id !== pick) }
    decks[slot.lo] = deck
  }
  return { qids: shuffle(chosen), decks }
}

/* ---------- weak areas: topic-driven ---------- */
export function weakTopics(s: State) {
  return topics.map(t => ({ t, ...loStatus(s, t.lo) }))
    .filter(x => x.status === 'Weak' || x.status === 'Average')
    .sort((a, b) => (a.status === b.status ? a.acc - b.acc : a.status === 'Weak' ? -1 : 1))
}
export function buildWeakSession(s: State, bank: Bank, onlyTopic?: string, max = 15): string[] {
  const list = onlyTopic ? [{ t: topicByCode[onlyTopic] }] : weakTopics(s)
  if (!list.length) return []
  const per = onlyTopic ? max : Math.max(2, Math.ceil(max / list.length))
  const seen = new Set(s.answers.map(a => a.qid))
  const out: string[] = []
  for (const { t } of list) {
    const pool = bank.questions.filter(q => q.lo === t.lo && q.usage === 'pool')
    const all = bank.questions.filter(q => q.lo === t.lo && q.usage !== 'lesson')
    const pending = all.filter(q => s.weak[q.id])
    const unseen = shuffle(pool.filter(q => !seen.has(q.id) && !s.weak[q.id]))
    const rest = shuffle(all.filter(q => !s.weak[q.id] && seen.has(q.id) && !s.retired.includes(q.id)))
    const retired = shuffle(all.filter(q => s.retired.includes(q.id)))
    const ordered = [...pending, ...unseen, ...rest, ...retired].map(q => q.id)
    for (const id of ordered) { if (out.length >= max) break; if (!out.includes(id) && out.filter(x => bank.byId[x].lo === t.lo).length < per) out.push(id) }
    if (out.length >= max) break
  }
  return out
}

/* ---------- lesson "Check yourself" ---------- */
export function coreCheck(bank: Bank, code: string): string[] {
  const t = topicByCode[code]
  const lessonQs = bank.questions.filter(q => q.topic === code && q.usage === 'lesson')
  if (lessonQs.length) return lessonQs.slice(0, 3).map(q => q.id)
  return shuffle(bank.questions.filter(q => q.lo === t.lo && q.usage === 'pool')).slice(0, 3).map(q => q.id)
}
export function replacementFor(bank: Bank, wrong: Question, exclude: string[]): string | null {
  const cands = bank.questions.filter(q => q.lo === wrong.lo && !exclude.includes(q.id) && (q.usage === 'pool' || q.usage === 'lesson'))
  const same = cands.filter(q => q.concept && q.concept === wrong.concept)
  const pick = shuffle(same)[0] ?? shuffle(cands.filter(q => q.usage === 'pool'))[0] ?? shuffle(cands)[0]
  return pick?.id ?? null
}
export function moreForTopic(s: State, bank: Bank, code: string, exclude: string[], n = 5): string[] {
  const t = topicByCode[code]
  const seen = new Set(s.answers.map(a => a.qid))
  const c = bank.questions.filter(q => q.lo === t.lo && q.usage === 'pool' && !exclude.includes(q.id))
  return [...shuffle(c.filter(q => !seen.has(q.id))), ...shuffle(c.filter(q => seen.has(q.id)))].slice(0, n).map(q => q.id)
}

export const statusColor: Record<Status, string> = { Strong: 'var(--strong)', Good: 'var(--good)', Average: 'var(--avg)', Weak: 'var(--weak)', 'Not started': 'var(--none)' }
export const fmtTime = (sec: number) => `${Math.floor(Math.max(0, sec) / 60)}:${String(Math.floor(Math.max(0, sec) % 60)).padStart(2, '0')}`
