import syllabusJson from './generated/syllabus.json'
import lessonsJson from './generated/lessons.json'
import cheatJson from './generated/cheatsheets.json'
import notesJson from './generated/sectionNotes.json'
import questionsJson from './generated/questions.json'
import testsJson from './generated/tests.json'
import blueprintsJson from './generated/blueprints.json'

export type K = 'K1' | 'K2' | 'K3'
export interface Topic { code: string; title: string; lo: string; k: K; pdfPages: [number, number]; chapter: number; section: string; sectionTitle: string }
export interface Chapter { number: number; title: string; minutes: number; examQuestions: number; sections: { code: string; title: string; topics: Topic[] }[] }
export interface Question {
  id: string; lo: string; k: K; chapter: number; topic: string; concept: string | null
  usage: string; source: string; stem: string; figure: string | null
  options: Record<string, string>; selectCount: number; correct: string[]; explanation: string
}
export interface Lesson { code: string; lo: string; k: K; title: string; readMinutes: number; body: string; trick?: { rule: string; trap: string; check: string } }
export interface Cheat { chapter: number; title: string; examQuestions: number; body: string }
export interface FixedTest { id: string; title: string; kind: 'original' | 'official'; qids: string[] }
export interface Blueprint { id: string; slots: { lo: string; k: K }[] }

const syl = syllabusJson as unknown as { chapters: Chapter[] }
export const chapters: Chapter[] = syl.chapters.map(c => ({
  ...c,
  sections: c.sections.map(s => ({ ...s, topics: s.topics.map(t => ({ ...t, chapter: c.number, section: s.code, sectionTitle: s.title })) })),
}))
export const topics: Topic[] = chapters.flatMap(c => c.sections.flatMap(s => s.topics))
export const topicByCode: Record<string, Topic> = Object.fromEntries(topics.map(t => [t.code, t]))
export const topicByLo: Record<string, Topic> = Object.fromEntries(topics.map(t => [t.lo, t]))
export const chapterByNo: Record<number, Chapter> = Object.fromEntries(chapters.map(c => [c.number, c]))

export const lessons = lessonsJson as unknown as Record<string, Lesson>
export const cheatsheets = cheatJson as unknown as Record<string, Cheat>
export const sectionNotes = notesJson as unknown as Record<string, string>
export const blueprints = blueprintsJson as unknown as Blueprint[]
const originalQs = questionsJson as unknown as Question[]
const originalTests = testsJson as unknown as FixedTest[]

export const EXAM = { questions: 40, minutes: 60, extendedMinutes: 75, passPercent: 65 }

/* ---------- official ISTQB content: imported at runtime from user-supplied files ---------- */
export interface Bank { questions: Question[]; byId: Record<string, Question>; tests: FixedTest[]; officialLoaded: boolean; officialCount: number }

interface PackItem { id: string; set: string; number: string; inMainExam: boolean; lo: string; k: K; chapter: number; stem: string; figure: string | null; options: Record<string, string>; selectCount: number; correct: string[]; explanation: string }

const stripSelect = (s: string) => s.replace(/\s*Select (ONE|TWO) options?\.?\s*$/i, '').trim()

export async function loadBank(): Promise<Bank> {
  let official: Question[] = []
  const offTests: FixedTest[] = []
  try {
    const res = await fetch(`${import.meta.env.BASE_URL}istqb/questions.json`)
    if (res.ok) {
      const items = (await res.json()) as PackItem[]
      const off = items.filter(i => ['A', 'B', 'C', 'D'].includes(i.set))
      official = off.map(i => ({
        id: i.id, lo: i.lo, k: i.k, chapter: i.chapter, topic: topicByLo[i.lo]?.code ?? '', concept: null,
        usage: i.inMainExam ? `off-${i.set}` : 'pool', source: `istqb-sample-${i.set}`, stem: stripSelect(i.stem),
        figure: i.figure, options: i.options, selectCount: i.selectCount, correct: i.correct, explanation: i.explanation,
      }))
      for (const s of ['A', 'B', 'C', 'D']) {
        const main = off.filter(i => i.set === s && i.inMainExam)
        main.sort((a, b) => Number(a.number) - Number(b.number))
        if (main.length === 40) offTests.push({ id: `off-${s}`, title: `ISTQB Sample Exam ${s}`, kind: 'official', qids: main.map(i => i.id) })
      }
    }
  } catch { /* file not supplied – original content only */ }
  const questions = [...originalQs, ...official]
  return {
    questions, byId: Object.fromEntries(questions.map(q => [q.id, q])),
    tests: [...offTests, ...originalTests], officialLoaded: official.length > 0, officialCount: official.length,
  }
}

export function isCorrect(q: Question, given: string[] | undefined) {
  if (!given || given.length !== q.correct.length) return false
  return [...given].sort().join() === [...q.correct].sort().join()
}
export const sourceLabel = (q: Question) =>
  q.source.startsWith('istqb-sample-') ? `ISTQB Sample Exam ${q.source.slice(-1)}` : q.usage === 'lesson' ? 'Lesson question' : 'Original question'
