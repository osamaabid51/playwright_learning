import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { Bank } from './data'

export type Ctx = 'lesson' | 'practice' | 'exam' | 'weak' | 'more'
export interface AnswerLog { qid: string; lo: string; ok: boolean; ts: number; ctx: Ctx; session: string }
export interface Warning { atSec: number; type: 'fullscreen' | 'tab' }
export interface Attempt {
  id: string; testId: string; title: string; kind: 'fixed' | 'random' | 'weak' | 'topic'
  mode: 'practice' | 'exam'; qids: string[]; answers: Record<string, string[]>; flags: string[]
  locked: Record<string, boolean>; startedAt: number; endedAt?: number; limitSec: number
  timerMode: 'off' | 'up' | 'down'; elapsedSec: number; resumedAt?: number
  status: 'active' | 'paused' | 'completed' | 'forfeited' | 'timeout'; warnings: Warning[]; current: number
}
export interface Note { id: string; topic: string; kind: 'note' | 'highlight' | 'mistake'; text: string; qid?: string; cheat: boolean; ts: number }
export interface TopicState { understood?: boolean; passed?: boolean; check?: { queue: string[]; done: Record<string, boolean>; idx: number } }
export interface State {
  topics: Record<string, TopicState>
  answers: AnswerLog[]
  attempts: Attempt[]
  decks: Record<string, string[]>
  recent: string[]
  weak: Record<string, { streak: number; lastSession: string }>
  retired: string[]
  notes: Note[]
  cheatAdds: Record<string, string[]>
}
const KEY = 'ctfl-personal-v1'
const empty: State = { topics: {}, answers: [], attempts: [], decks: {}, recent: [], weak: {}, retired: [], notes: [], cheatAdds: {} }

function load(): State {
  try { const raw = localStorage.getItem(KEY); if (raw) return { ...empty, ...JSON.parse(raw) } } catch { /* ignore */ }
  return empty
}

interface Store { s: State; set: (fn: (s: State) => State) => void; bank: Bank }
const StoreCtx = createContext<Store | null>(null)

export function StoreProvider({ bank, children }: { bank: Bank; children: ReactNode }) {
  const [s, setS] = useState<State>(load)
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(s)) } catch { /* storage full/blocked */ } }, [s])
  return <StoreCtx.Provider value={{ s, set: fn => setS(prev => fn(prev)), bank }}>{children}</StoreCtx.Provider>
}
export function useStore() { const v = useContext(StoreCtx); if (!v) throw new Error('no store'); return v }

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4)

/** Record answers + maintain the weak-areas list (topic-driven retirement rule). */
export function logAnswers(s: State, entries: { qid: string; lo: string; ok: boolean }[], ctx: Ctx, session: string): State {
  const ts = Date.now()
  const weak = { ...s.weak }
  let retired = s.retired
  for (const e of entries) {
    if (!e.ok) weak[e.qid] = { streak: 0, lastSession: session }
    else if (weak[e.qid]) {
      const w = weak[e.qid]
      if (w.lastSession !== session) {
        const streak = w.streak + 1
        if (streak >= 2) { delete weak[e.qid]; retired = [...retired.filter(r => r !== e.qid), e.qid] }
        else weak[e.qid] = { streak, lastSession: session }
      }
    }
  }
  return { ...s, weak, retired, answers: [...s.answers, ...entries.map(e => ({ ...e, ts, ctx, session }))] }
}
