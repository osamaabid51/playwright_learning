import { StrictMode, useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'
import App from './App'
import { loadBank, type Bank } from './data'
import { StoreProvider } from './store'

function Root() {
  const [bank, setBank] = useState<Bank | null>(null)
  useEffect(() => { loadBank().then(setBank) }, [])
  if (!bank) return <div className="loading">Loading…</div>
  return <StoreProvider bank={bank}><App /></StoreProvider>
}
createRoot(document.getElementById('root')!).render(<StrictMode><Root /></StrictMode>)
