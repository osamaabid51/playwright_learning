#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Node.js is not installed. Install the LTS version from https://nodejs.org and run this again."; exit 1; }
[ -d node_modules ] || { echo "Installing dependencies, first run only..."; npm install || exit 1; }
echo "Starting CTFL Prep at http://localhost:5173 (press Ctrl+C to stop)"
npm run dev
