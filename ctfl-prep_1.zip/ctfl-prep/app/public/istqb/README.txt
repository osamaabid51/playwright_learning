Put your own copies of the official ISTQB files here (personal use only):

  syllabus.pdf    - ISTQB CTFL Syllabus v4.0.1 (free download from istqb.org)
  questions.json  - data/questions.json from the first content pack (Sample Exams A-D)

Both are optional. Reload the app after adding them.
