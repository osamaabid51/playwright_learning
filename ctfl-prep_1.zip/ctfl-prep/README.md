# CTFL Prep

Study app for the ISTQB® CTFL v4.0 exam: lessons + notebook, cheat sheets, mock exams (practice / exam mode), results and progress.

## Start here (2 steps)

1. Install **Node.js LTS** from https://nodejs.org (one time).
2. Open the `app` folder and double-click:
   - **Windows:** `start-windows.bat`
   - **Mac / Linux:** `start-mac-linux.command` (Mac: right-click → Open the first time)

The first run installs dependencies (1–2 min); then the app opens at **http://localhost:5173**. Keep the window open while you use the app.

Manual alternative: `cd app` → `npm install` → `npm run dev`.

## Optional: official ISTQB files (your own copies, personal use)
Put them in `app/public/istqb/` and reload — see `app/README.md`. The app works fully without them.

## More
- Full product / content / engineering guide (for people and AI agents): `AGENTS.md`
- Content: `data/` (original material only; schema in `data/SCHEMA.md`)

Independent study material — not affiliated with or endorsed by ISTQB®.
