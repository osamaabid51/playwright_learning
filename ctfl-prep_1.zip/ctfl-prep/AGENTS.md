# CTFL Prep — product & engineering knowledge file

This file is the single source of truth for this project. It is written for any engineer or AI coding agent (Claude, Codex, Cursor, Copilot, Gemini…) that needs to **understand, fix, extend, or rebuild** the product. Read it fully before changing anything. If you change behaviour, update this file in the same change.

---

## 1. What the product is

A study platform for the **ISTQB® Certified Tester Foundation Level (CTFL) v4.0** exam (syllabus **v4.0.1**). It combines four things in one place:

1. **Learn**: short lessons per syllabus topic, with a notebook beside the lesson and an inline "Check yourself" quiz.
2. **Cheat sheets**: must-know notes per chapter, plus the learner's own additions.
3. **Mock exams**: full 40-question exams that match the real exam pattern, in **Practice** mode (instant feedback) or **Exam** mode (fullscreen, timed, strict).
4. **Progress**: topic-wise strengths and weaknesses, syllabus coverage, exam readiness, history, and a weak-areas practice mode.

### Two versions, one codebase and data model

| | Personal (this repo, localhost) | Public (planned) |
|---|---|---|
| Who | The owner, own exam prep | Anyone, hosted website |
| Content | Original content + **official ISTQB files the user supplies at runtime** | **Original content only** |
| Storage | Browser `localStorage` | Accounts + database (see §10) |
| Official syllabus | User drops `syllabus.pdf` into `app/public/istqb/`; each lesson opens the matching pages | Not available |
| Official sample exams | User drops `questions.json` (sets A–D) into `app/public/istqb/` → 4 extra mocks + added to random pool | Not available |

**Hard rule:** the repository never contains ISTQB-authored text (syllabus prose, sample-exam questions, glossary definitions). Chapter/section **titles** and LO codes/K-levels are factual and may be used. See §5.

---

## 2. Exam facts (drive everything)

| Item | Value |
|---|---|
| Questions | 40 multiple choice, 1 point each, no negative marking |
| Time | 60 min (75 min for candidates taking it in a non-native language) |
| Pass mark | 26/40 = **65%** |
| K-levels per exam | K1 = 8, K2 = 24, K3 = 8 |
| Questions per chapter | Ch1 8 · Ch2 6 · Ch3 4 · Ch4 11 · Ch5 9 · Ch6 2 |
| Question types | Select ONE (4 options a–d) or Select TWO (5 options a–e) |
| Syllabus | 6 chapters, **64 leaf topics, exactly one learning objective (LO) per leaf topic** |

Chapter study minutes (used to weight coverage): Ch1 180, Ch2 130, Ch3 80, Ch4 390, Ch5 335, Ch6 20.

**Exam blueprint:** an ordered list of 40 `{lo, k}` slots. Four blueprints (`bp-A..D`, LO/K patterns only) are stored in `data/public/blueprints.json`. Any test built slot by slot from a blueprint automatically has the correct K and chapter distribution.

---

## 3. Product specification (agreed decisions, keep them)

### 3.1 Navigation and header metrics
Tabs: **Learn · Cheat sheets · Mock exams · My progress**, plus a small **Data** link.

| Area | Header shows |
|---|---|
| Learn, Cheat sheets | **Syllabus coverage** only (`64% · 38 / 64 topics`) |
| Mock exams, Practice, Results, Review | **Exam readiness** only (`78% · Ready`) |
| My progress | Both, in the page body |
| Exam mode | Nothing but the exam UI |

The two metrics are deliberately different and must not be merged:
- **Syllabus coverage** = how much of the syllabus is completed. It only goes up.
- **Exam readiness** = would you pass today. It is computed from Exam-mode attempts only and can go down.

### 3.2 Learn
- Three columns: **left** syllabus tree with coverage % per chapter and section, and a status per topic (Passed / Checking / —). **Centre** is the lesson. **Right** is the **notebook**, always open.
- A lesson is **minimal**: 150–300 words. It has a 1–2 sentence definition, 3–5 key points, **exactly one example**, an optional single table, and an optional **exam-trick card** (Rule / Trap / Check). The trick card is added only where a real exam trap exists. Do not pad content just because generating it is cheap.
- The "Check yourself" quiz is **hidden** until the learner clicks **"Understood — check yourself"**.
- **Check yourself:**
  - Core set: 3 lesson questions for that topic, with instant feedback and per-option rationale.
  - A wrong answer shows the rationale and then adds a **replacement question on the same concept** (or same LO) from the pool.
  - The topic is **Passed** only when **every** question, including replacements, has been answered correctly. Passing updates syllabus coverage.
  - The learner can leave or skip at any time and is never blocked.
- After passing, an optional **"Give me more"** button gives 5 more pool questions on that topic, as many times as wanted.
- **"Official syllabus p. X–Y"** button (personal version) opens a drawer that renders those PDF pages with pdf.js.
- **Notebook:**
  - Filters: This topic / Chapter / Mistakes / All.
  - Note kinds: `note`, `highlight` (select lesson text → "+ Add to notebook"), and `mistake` (one click from any wrongly answered question).
  - Each note has an "On my cheat sheet" toggle.

### 3.3 Cheat sheets
- One per chapter, **must-know items only**: lists, chains, formulas and distinctions the exam tests directly. Terse `**Label:** a · b · c` lines with no explanations; it should fit about one screen.
- Side block **"My additions"**: notes toggled "On my cheat sheet", plus free lines the user adds. Course content and user content are visually distinct (user content is yellow).
- Print / PDF via the browser print stylesheet.

### 3.4 Mock exams
- **Choose a test:**
  - 10 **fixed** original mocks (Mock 1–10), always the same 40 questions, for benchmarking.
  - Personal version only: + ISTQB Sample Exams A–D when supplied.
  - A **Randomised mock**.
- **Choose a mode:**
  - **Practice:** answer, then rationale shown immediately and answer locked. Optional timer (off / count-up / 60-min countdown). Pause and resume. Notebook open with "Save as mistake". Does **not** count toward readiness.
  - **Exam mode:** a rules screen first (40 Q / 60 min / pass 26 / one-warning rule / optional 75 min). Then fullscreen, countdown, question map, flag for review, change answers until submit. No feedback until the end.
- **Exam-mode leaving rules.** A web page cannot lock the OS; fullscreen is a focus aid plus detection:

| Event | 1st time | 2nd time |
|---|---|---|
| Leaves fullscreen (Esc) / switches tab or app (blur, visibility hidden) | Warning overlay, logged with time; **timer keeps running**; "Return to fullscreen" | **Forfeit**: scored on answered questions, result shown |
| Reload / close / revisit an active exam not started in this page session | — | Forfeit immediately |
| Timer reaches 0:00 | Auto-submit (`timeout`) | — |

Both events of one exit within 2 s count as a single violation. Unanswered questions count as wrong.

### 3.5 Randomised mock (question selection)
1. Pick a random blueprint (40 `{lo,k}` slots).
2. For each slot, candidates = all non-lesson questions with that LO (fixed-mock + pool, + official in personal).
3. **No same type in one test:** at most one question per `concept` tag in a test.
4. **Minimise repeats across attempts:** keep a per-user **deck per LO** (shuffled list of question ids). Draw from the deck without replacement. Refill only when the deck is exhausted, and put the questions from the user's last randomised attempt at the end of the new deck.
5. Shuffle the final order.

With 800 bank questions (400 fixed + 400 pool, sized by LO frequency in the blueprints) a user gets about 20 randomised attempts before a question repeats. The figure varies per LO.

### 3.6 Results (after any mock)
- Score, pass/fail vs 26/40 (only for 40-question tests), status chips (Forfeited, Time ran out, each warning with timestamp), K1/K2/K3 breakdown.
- **Feedback is topic-based, not question-based:** a chapter table (this-test score, status), expandable to LOs. Chapters below 70% auto-expand. Each weak LO has **Revise lesson** and **Practise** links (Practise = short topic session).
- Per-question review with rationale is one link away (filters: Wrong / Flagged / All).

### 3.7 Topic status (shared everywhere)
For each LO, use the last 10 answers from all contexts (lesson, practice, exam, weak). The accuracy is recency-weighted (weights 1…10, newest heaviest). At least 3 answers are needed, otherwise the status is "Not started".

| Status | Accuracy |
|---|---|
| Strong | ≥ 95% |
| Good | ≥ 85% |
| Average | ≥ 70% |
| Weak | < 70% |

### 3.8 Exam readiness
- Uses the last 3 **Exam-mode** 40-question attempts (completed, forfeited or timed out), weighted 3/2/1 with the newest heaviest.
- Verdict: **Not ready < 65 · Borderline 65–74 · Ready ≥ 75**.
- With no exam-mode attempt yet, show "Take an exam-mode mock to measure readiness".

### 3.9 Syllabus coverage
Sum of weights of **Passed** topics ÷ total, where a topic's weight = chapter minutes ÷ topics in that chapter.

### 3.10 Weak-areas mode
- Picks topics with status **Weak** first, then **Average**, weakest first. Up to 15 questions, spread across those topics. It is not blueprint-based and not counted toward readiness.
- Order within a topic:
  1. Questions on the pending list (answered wrong anywhere)
  2. Unseen pool questions
  3. Other seen questions
  4. Retired questions, last
- **Retirement:** a pending question leaves the list after it is answered correctly in **2 consecutive sessions**. A wrong answer resets the count. Retired questions are reused only after all their replacements have been used.
- A topic leaves the weak list once its status reaches **Good**.

### 3.11 My progress
- Coverage card + readiness card.
- **Topic map:** 64 tiles coloured by status, outlined if the lesson is passed. Clicking a tile opens the lesson. Plus a "Practise my weak areas" button.
- Exam-mode score trend vs the 65% line.
- Attempt history table (date, test, mode, score, result, forfeits/warnings).
- Small activity line: streak, answers this week, notes and mistakes count. No badges or leaderboards.

### 3.12 Visual design tokens
- Fonts: Source Serif 4 (headings), IBM Plex Sans (UI), IBM Plex Mono (codes).
- Colours: ground `#F4F5F7`, surface `#FFF`, ink `#15171C`, brand `#1D3C9E`.
- Status colours: Strong `#1E7A46`, Good `#2952CC`, Average `#E8A33D`, Weak `#C9372C`.
- Notebook: cream `#FFFDF5`, highlight `#FFF1C2`.
- No emoji, no gradients. Real `<button>`/`<label>` elements for accessibility.
- See `app/src/styles.css`.

---

## 4. Repository layout

```
AGENTS.md                 ← this file
README.md                 ← quick start
data/                     ← ALL content (source of truth, original only)
  SCHEMA.md               ← data schema reference
  shared/syllabus.json    ← chapters → sections → 64 topics {code,title,lo,k,pdfPages}
  public/lessons/<code>.md        ← 64 lessons (YAML front matter + Markdown body)
  public/cheatsheets/<ch>.md      ← 6 cheat sheets
  public/questions/lesson_*.json  ← 192 lesson questions (3 per topic), by author batch
  public/questions/bank_*.json    ← 800 bank questions, by author batch
  public/questions.json           ← MERGED set used by the app (lesson + bank, with usage assigned)
  public/mocks.json               ← 10 fixed mocks {id,title,blueprint,qids[40]}
  public/blueprints.json          ← 4 exam blueprints (LO/K slot patterns)
  public/bank_quota.json          ← bank size per LO (= 5 × occurrences across the 4 blueprints)
  public/LESSON_BRIEF.md, BANK_BRIEF.md ← writing briefs used to produce content (reuse for new content)
scripts/validate_data.py  ← validates content rules; --reassign rebuilds mocks/pool; --official checks overlap
app/                      ← personal web app (Vite + React 19 + TypeScript, no backend)
  scripts/build_data.py   ← data/ → app/src/generated/*.json (run after any content change)
  public/istqb/           ← user-supplied official files (never committed)
  src/data.ts             ← types, static content imports, runtime import of official files
  src/store.tsx           ← app state (React context) persisted to localStorage; answer logging + weak list
  src/logic.ts            ← status, coverage, readiness, scoring, randomiser, weak sessions, check-yourself picking
  src/components/ui.tsx   ← Layout/header, Markdown, QuestionView, Rationale, chips, bars
  src/components/Notebook.tsx, PdfPanel.tsx
  src/pages/Learn.tsx, CheatSheets.tsx, MockHub.tsx, Exam.tsx, Practice.tsx, Results.tsx (+Review), Progress.tsx, Setup.tsx
  src/styles.css
```

Routes (HashRouter): `/learn/:code`, `/cheatsheets/:ch`, `/mocks`, `/exam/:id` (no layout), `/practice/:id`, `/results/:id`, `/review/:id`, `/progress`, `/setup`.

---

## 5. Content rules (copyright and quality)

**Copyright, non-negotiable:**
- Never copy or closely paraphrase ISTQB syllabus prose, sample-exam questions or glossary definitions into `data/`. Write in your own words from knowledge of the concepts.
- Do not reuse official sample-exam scenarios (e.g. the grade-calculator BVA, the wine-storage BVA, the bicycle-rental decision table).
- Allowed: chapter/section titles, LO codes, K-levels, keyword terms (bare terms), standard technical vocabulary.
- Official material reaches the personal app **only** via files the user places in `app/public/istqb/` at runtime.
- The public version must state that it is independent material, not affiliated with ISTQB®, must not use the ISTQB logo, and must not call itself "official".
- Check: `python3 scripts/validate_data.py --official <first-pack questions.json>` fails any question with ≥ 20% word-6-gram overlap with an official question.

**Lessons** (`data/public/lessons/<code>.md`):
```
---
code: "4.2.2"
lo: "FL-4.2.2"
k: "K3"
title: "Boundary Value Analysis"
readMinutes: 2            # ceil(words/200)
trick:                    # optional, only for a real exam trap
  rule: "..."
  trap: "..."
  check: "..."
visibility: public
---
<1–2 sentence definition>

**Key points**
- 3–5 bullets

### Example
<exactly one concrete example; K3 topics: a small worked example with numbers>
```
Use precise English and ISTQB v4.0.1 terminology. Exam-relevant content only.

**Questions** (`Question` object, see `data/SCHEMA.md`):
- Fields: `id, lo, k, chapter, topic, concept, usage, source:"original", visibility:"public", stem, figure:null, options{a..d|e}, selectCount, correct[], rationale{letter: one sentence}`.
- id prefixes: `L-<topic>-NN` for lesson questions, `B-<lo>-NN` / `G-<lo>-N` for bank questions.
- `usage`: `lesson` | `mock-1`…`mock-10` | `pool`. Bank questions are assigned by `validate_data.py --reassign`.
- K-level must equal the LO's K-level. K3 means application or calculation, and every calculation must be verified programmatically.
- One unambiguous key. Plausible distractors of similar length. No "all/none of the above".
- **The correct option must not be the longest in more than 30% of questions** (currently 18%, counting ties).
- Correct letters balanced across a/b/c/d. Select TWO is about 8% of questions.
- The stem must not contain "Select ONE/TWO option(s)" (the UI adds it). Tables, state tables and pseudocode go in the stem as Markdown.
- `concept`: a kebab-case tag finer than the LO. Within an LO, no concept is used by more than 3 bank questions; an LO with 10+ questions needs 5+ concepts.
- Lesson questions: exactly 3 per topic, with 3 different concepts, and not duplicated in the bank.

**Cheat sheets:** `**Label:** item · item · item` lines only; must-know content; no examples.

---

## 6. Data pipeline and commands

```
# validate content (run before every commit that touches data/)
python3 scripts/validate_data.py [--official path/to/first-pack/questions.json]

# after adding/editing lesson_*.json or bank_*.json: merge + re-assign mocks/pool (changes fixed mocks!)
python3 scripts/validate_data.py --reassign

# regenerate app data (after ANY change under data/)
python3 app/scripts/build_data.py          # needs PyYAML

# run the app
cd app && npm install && npm run dev        # http://localhost:5173
npm run build && npm run preview            # production build check (also runs tsc)
```

Editing a single question in place: edit it in **both** its batch file (`questions/lesson_*.json` or `bank_*.json`) **and** `public/questions.json`, then validate and rebuild. Do not use `--reassign` for small fixes, because it reshuffles the fixed mocks.

**Bank sizing:** `total(LO) = 5 × (occurrences of LO across the 4 blueprints)`. That gives 800 = 20 blueprint instances. The first 10 instances (blueprint A,B,C,D,A,B,…) become the fixed mocks; the rest is the pool.

---

## 7. App architecture notes

- **No backend.** All static content is imported from `src/generated/*.json` at build time. Official files are fetched at runtime from `public/istqb/` (`loadBank()` in `data.ts`); if they are missing, the app works with original content only.
- **State** (`localStorage` key `ctfl-personal-v1`), shape in `store.tsx`:
  - `topics[code]`: `{understood, passed, check{queue, done, idx}}`
  - `answers[]`: `{qid, lo, ok, ts, ctx, session}`. This drives every status.
  - `attempts[]`: tests, with mode, status, answers, flags, warnings, timer fields
  - `decks{lo: qid[]}` and `recent[]`: the randomiser
  - `weak{qid:{streak,lastSession}}` and `retired[]`: the weak list
  - `notes[]`, `cheatAdds{chapter: string[]}`
- `logAnswers()` is the only way answers are recorded; it also maintains the weak list.
- **Exam mode** (`pages/Exam.tsx`):
  - A module-level `liveExamId` marks the exam started in this page session. If an active exam is opened without it (reload, closed tab), it is forfeited.
  - Listeners: `fullscreenchange`, `visibilitychange`, `blur`, `beforeunload`.
  - Remaining time = `limitSec − (now − startedAt)`, so it can't be extended by reloading.
- PDF rendering is lazy-loaded (`pdfjs-dist`) and renders only the topic's page range.
- Data / setup page: shows what is loaded, export/import progress JSON, and reset.

---

## 8. Quality checklist for any change

- [ ] `python3 scripts/validate_data.py` prints OK (and with `--official` if you have the file)
- [ ] `python3 app/scripts/build_data.py` and `cd app && npm run build` succeed (tsc is strict)
- [ ] Every fixed mock still matches the blueprint (40 · 8/24/8 · 8/6/4/11/9/2). The validator checks this.
- [ ] Manual smoke test of the full flow:
  - [ ] Lesson → Understood → wrong answer → replacement → pass → coverage updates
  - [ ] Practice mock → results
  - [ ] Exam mode: one warning on leaving; second exit forfeits; reload forfeits
  - [ ] Progress page
- [ ] Copyright rules in §5 respected; no ISTQB text added
- [ ] This file updated if behaviour or structure changed

---

## 9. Known issues / open items

- `B-4.5.3-02` and `B-4.5.3-13` share the same user-story scenario. They have the same concept tag, so they never appear in the same test.
- Some lessons carry a trick card where the trap is weak (e.g. 5.3.3, 5.4). Consider removing them.
- Questions whose options are identical-length codes (matching "1A, 2B…", roman numerals) inevitably tie for the longest option. This is accepted.
- The main JS bundle is about 1.6 MB, mostly the question JSON. Code-split per route or lazy-load question data if needed.
- No dark mode yet. Desktop-first; mobile layout is functional but not polished.

---

## 10. Public version (planned, not built)

- **Stack:**
  - Next.js (App Router) + Supabase: Postgres, Auth (email + Google), Row Level Security.
  - Lessons as MDX or DB rows.
  - Questions, mocks and blueprints in tables mirroring `data/public/*`.
- **Data:** same content, `visibility = public` only. Never ship personal/official files.
- **Tables (suggested):**
  - `profiles`
  - `answers(user_id, qid, lo, ok, ctx, session, ts)`
  - `attempts(...)` with the same fields as the local `Attempt`
  - `topic_progress(user_id, code, understood, passed)`
  - `decks(user_id, lo, qids[])`
  - `weak(user_id, qid, streak, last_session)`
  - `notes(...)`, `cheat_additions(...)`
- **Server-side:** the exam timer (store `started_at` server-side and score on the server), randomiser, and readiness. These stop clients tampering with them.
- **Pages:**
  - Home (what ISTQB/CTFL is, why certify)
  - Lessons
  - Practice (topic-wise)
  - Mock exams
  - Dashboard
  - About/Disclaimer ("independent prep material, not affiliated with ISTQB®")
  - Privacy policy and cookie consent (needed once there are accounts and ads)
- **Monetisation hooks (later):** ads on dashboard and between sections only, never inside exam mode; a premium tier.

---

## 11. Rebuilding a similar product from scratch (recipe)

1. Model the syllabus as chapters → sections → leaf topics, one LO per leaf (code, title, LO, K). Store the official PDF page range per topic only if the user supplies the PDF.
2. Derive exam blueprints (`{lo,k}` × 40) that satisfy the K and chapter distribution.
3. Write content with the briefs in `data/public/LESSON_BRIEF.md` and `BANK_BRIEF.md`:
   - 1 lesson + 3 check questions per topic
   - Bank size per LO = 5 × blueprint frequency
   - Validate with `scripts/validate_data.py`
4. Assign the bank: 10 fixed mocks (one blueprint each, unique concepts) and the rest as pool.
5. Build the UI per §3, using the state model in §7 and the algorithms in §3.5–3.10.
6. Run the checklist in §8.
