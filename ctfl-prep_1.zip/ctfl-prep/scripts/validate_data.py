"""Validate the public content set and (optionally) rebuild the 10 fixed mocks + pool.

Usage (from the repo root):
  python3 scripts/validate_data.py                         # validate only
  python3 scripts/validate_data.py --official path/to/questions.json
        # also check similarity against official ISTQB sample-exam questions
        # (the questions.json from the first content pack; items with set A–D)
  python3 scripts/validate_data.py --reassign              # re-merge lesson_*/bank_* files into
        # data/public/questions.json and RE-ASSIGN all bank questions to mock-1..10 / pool.
        # Changes the fixed mocks — users' attempt history for Mock N will then refer to a
        # different question set. Only do this deliberately.

Exit code 1 if any hard rule fails.
"""
import argparse, collections, glob, json, os, random, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D = os.path.join(ROOT, 'data')
ap = argparse.ArgumentParser()
ap.add_argument('--official'); ap.add_argument('--reassign', action='store_true')
args = ap.parse_args()

syl = json.load(open(f'{D}/shared/syllabus.json', encoding='utf-8'))
topics = {t['lo']: t for c in syl['chapters'] for s in c['sections'] for t in s['topics']}
quota = json.load(open(f'{D}/public/bank_quota.json', encoding='utf-8'))
bps = json.load(open(f'{D}/public/blueprints.json', encoding='utf-8'))

if args.reassign:
    lesson = [q for f in sorted(glob.glob(f'{D}/public/questions/lesson_*.json')) for q in json.load(open(f, encoding='utf-8'))]
    bank = [q for f in sorted(glob.glob(f'{D}/public/questions/bank_*.json')) for q in json.load(open(f, encoding='utf-8'))]
else:
    allq0 = json.load(open(f'{D}/public/questions.json', encoding='utf-8'))
    lesson = [q for q in allq0 if q['usage'] == 'lesson']
    bank = [q for q in allq0 if q['usage'] != 'lesson']
allq = lesson + bank
errs, warns = [], []

# ---- per-question rules ----
for i, n in collections.Counter(q['id'] for q in allq).items():
    if n > 1: errs.append(f'duplicate id {i}')
for q in allq:
    t = topics.get(q['lo'])
    if not t: errs.append(f"{q['id']}: unknown LO {q['lo']}"); continue
    if q['k'] != t['k']: errs.append(f"{q['id']}: K {q['k']} != syllabus {t['k']}")
    if q.get('topic') != t['code']: errs.append(f"{q['id']}: topic {q.get('topic')} != {t['code']}")
    if q['chapter'] != int(t['code'][0]): errs.append(f"{q['id']}: chapter mismatch")
    if len(q['correct']) != q['selectCount'] or any(c not in q['options'] for c in q['correct']): errs.append(f"{q['id']}: answer key")
    if set(q.get('rationale', {})) != set(q['options']): errs.append(f"{q['id']}: rationale keys != option keys")
    if re.search(r'Select (ONE|TWO)', q['stem']): errs.append(f"{q['id']}: stem contains 'Select ONE/TWO'")
    if not q.get('concept'): errs.append(f"{q['id']}: missing concept")
    if q.get('visibility', 'public') != 'public' or q.get('source', 'original') != 'original': errs.append(f"{q['id']}: not public/original")

# ---- set-level rules ----
lc = collections.Counter(q['lo'] for q in lesson)
for lo in topics:
    if lc[lo] != 3: errs.append(f'{lo}: {lc[lo]} lesson questions (expected 3)')
bc = collections.Counter(q['lo'] for q in bank)
for lo, v in quota.items():
    if bc[lo] != v['total']: errs.append(f"{lo}: bank {bc[lo]} != quota {v['total']}")
for lo in topics:
    cc = collections.Counter(q['concept'] for q in bank if q['lo'] == lo)
    if cc and max(cc.values()) > 3: warns.append(f'{lo}: a concept is used {max(cc.values())}× in the bank')
longest = sum(max(len(v) for v in q['options'].values()) == max(len(q['options'][c]) for c in q['correct']) for q in allq) / len(allq)
if longest > 0.30: errs.append(f'correct option is (tied) longest in {longest:.0%} of questions (max 30%)')
lessons = glob.glob(f'{D}/public/lessons/*.md')
if len(lessons) != len(topics): errs.append(f'{len(lessons)} lessons for {len(topics)} topics')
for p in lessons:
    words = len(open(p, encoding='utf-8').read().split('---', 2)[2].split())
    if not 150 <= words <= 330: warns.append(f'{os.path.basename(p)}: {words} words (target 150–300)')

# ---- similarity ----
def grams(t, n=6):
    w = re.findall(r'[a-z0-9]+', t.lower()); return {' '.join(w[i:i + n]) for i in range(len(w) - n + 1)}
G = {q['id']: grams(q['stem'] + ' ' + ' '.join(q['options'].values())) for q in allq}
by_lo = collections.defaultdict(list)
for q in allq: by_lo[q['lo']].append(q['id'])
for ids in by_lo.values():
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            a, b = G[ids[i]], G[ids[j]]
            if a and b and len(a & b) / min(len(a), len(b)) > 0.5: warns.append(f'near-duplicate: {ids[i]} ~ {ids[j]}')
if args.official:
    off = [o for o in json.load(open(args.official, encoding='utf-8')) if o.get('set') in 'ABCD']
    offG = [(o['id'], grams(o['stem'] + ' ' + ' '.join(o['options'].values()))) for o in off]
    for q in allq:
        g = G[q['id']]
        for oid, og in offG:
            if g and len(g & og) / len(g) >= 0.20: errs.append(f"{q['id']}: {len(g & og) / len(g):.0%} 6-gram overlap with official {oid}")

# ---- (re)assign mocks ----
if args.reassign and not errs:
    rng = random.Random(42)
    avail = collections.defaultdict(list)
    for q in bank: avail[q['lo']].append(q)
    for lo in avail: rng.shuffle(avail[lo])
    mocks = []
    for m in range(10):
        bp = bps[m % len(bps)]
        used, chosen = set(), []
        for slot in bp['slots']:
            cands = [q for q in avail[slot['lo']] if q['concept'] not in used] or avail[slot['lo']]
            cc = collections.Counter(q['concept'] for q in avail[slot['lo']])
            q = max(cands, key=lambda x: (cc[x['concept']], rng.random()))
            avail[slot['lo']].remove(q); used.add(q['concept']); chosen.append(q)
        rng.shuffle(chosen)
        for q in chosen: q['usage'] = f'mock-{m + 1}'
        mocks.append({'id': f'mock-{m + 1}', 'title': f'Mock {m + 1}', 'blueprint': bp['id'], 'qids': [q['id'] for q in chosen]})
    for lst in avail.values():
        for q in lst: q['usage'] = 'pool'
    for q in allq: q.setdefault('figure', None)
    json.dump(allq, open(f'{D}/public/questions.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump(mocks, open(f'{D}/public/mocks.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('re-assigned 10 mocks + pool')

# fixed-mock blueprint check
qs = {q['id']: q for q in json.load(open(f'{D}/public/questions.json', encoding='utf-8'))}
for m in json.load(open(f'{D}/public/mocks.json', encoding='utf-8')):
    ms = [qs[i] for i in m['qids']]
    k = collections.Counter(q['k'] for q in ms); c = collections.Counter(q['chapter'] for q in ms)
    if len(ms) != 40 or k != {'K1': 8, 'K2': 24, 'K3': 8} or [c[i] for i in range(1, 7)] != [8, 6, 4, 11, 9, 2]:
        errs.append(f"{m['id']}: does not match the exam blueprint ({dict(k)}, {[c[i] for i in range(1, 7)]})")
    if len({q['concept'] for q in ms}) != 40: warns.append(f"{m['id']}: repeated concept inside the mock")

print(f'lesson questions {len(lesson)} · bank {len(bank)} · lessons {len(lessons)} · correct-longest {longest:.0%}')
for w in warns: print('WARN ', w)
for e in errs: print('ERROR', e)
print('OK' if not errs else f'{len(errs)} error(s)')
sys.exit(1 if errs else 0)
