# CTFL Prep – data schema

All content lives under `data/`. Both the personal and public builds read the same schema. Every item carries `visibility`: `public` (original, safe to publish) or `personal` (ISTQB-owned; local use only, never bundled in the public build).

## shared/syllabus.json
Outline only (headings are factual): chapters → sections → topics (64 leaf topics, one per learning objective).
`topic = { code, title, lo, k, pdfPages: [from, to] }` — `pdfPages` are page numbers in the official ISTQB CTFL v4.0.1 syllabus PDF (used by the personal build's PDF panel).

## public/lessons/<code>.md
One lesson per leaf topic. Front matter:
```
---
code: "4.2.2"
lo: "FL-4.2.2"
k: "K3"
title: "Boundary Value Analysis"
readMinutes: 2
trick:                       # optional – only where a real exam trap exists
  rule: "..."
  trap: "..."
  check: "..."
visibility: public
---
```
Body (150–300 words): definition (1–2 sentences) → key points (3–5 bullets) → `### Example` (one) → optional table. Original wording only.

## public/questions/*.json – array of Question
```
{
  "id": "L-4.2.2-01",          // L- lesson, M-<mock>-<nn> fixed mock, P- pool, O- official
  "lo": "FL-4.2.2", "k": "K3", "chapter": 4, "topic": "4.2.2",
  "concept": "bva-2value-coverage-calc",   // finer than LO; one per concept per test
  "usage": "lesson" | "mock-1".."mock-10" | "pool",
  "source": "original" | "istqb-sample-A" ...,
  "visibility": "public" | "personal",
  "stem": "...", "figure": null,
  "options": {"a": "...", "b": "...", "c": "...", "d": "..."},
  "selectCount": 1,
  "correct": ["b"],
  "rationale": {"a": "why wrong", "b": "why right", "c": "...", "d": "..."}
}
```
Rules: correct answer is NOT systematically the longest option (target ≤ 30% of questions); correct letters balanced; ISTQB terminology; no copying of ISTQB text.

## public/blueprints.json
40-slot exam blueprints: `[{ "id": "bp-A", "slots": [{"lo": "FL-1.1.1", "k": "K1"}, ...] }]` (LO/K pattern only).

## public/cheatsheets/<chapter>.md
Must-know items only, terse; sections as `**Label:** content` lines.

## personal/
Nothing ISTQB-authored is stored in the repo. The personal build imports, at runtime, files the user supplies in `app/public/istqb/`: the official syllabus PDF and `questions.json` from the first content pack (official sample exams).
