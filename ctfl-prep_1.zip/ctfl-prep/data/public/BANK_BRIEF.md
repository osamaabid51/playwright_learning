# Brief: mock / pool question bank (PUBLIC, original content)

Read /home/claude/ctfl/data/SCHEMA.md first. No browser tools. Never copy or paraphrase ISTQB text or official sample-exam questions (/home/claude/istqb/data/exam_*.json — read the ones for your LOs only to AVOID them).

Quotas: /home/claude/ctfl/data/public/bank_quota.json → for each LO: `total` questions needed, `existing` (already written earlier, in /home/claude/istqb/data/gen_ch*.json), `new` to write. You own only the LOs listed in your task.

## 1. Convert + fix the existing questions for your LOs
For every existing question of your LOs (gen_ch*.json, matching `lo`):
- Convert to the SCHEMA.md Question format: keep `id`, set `topic` (from /home/claude/ctfl/data/shared/syllabus.json, LO → topic code), `usage: "bank"`, `source: "original"`, `visibility: "public"`, strip the trailing "Select ONE/TWO option(s)." from `stem`, turn the explanation into a `rationale` object (one short sentence per option).
- Add a `concept` tag (kebab-case, specific, e.g. `bva-3value-additional-inputs`).
- FIX option lengths: the correct option must not stand out as the longest. Rewrite distractors (or tighten the correct option) so options are similar in length.
- Fix anything factually wrong or ambiguous.

## 2. Write the NEW questions
Exactly `new` additional questions per LO. ids: `B-<lo code without FL->-<nn>` (e.g. `B-4.2.2-07`). Same schema, usage "bank".
- Scenario-based where possible; varied formats like the real exam: mostly single-choice, ~8% Select TWO (5 options a–e, selectCount 2), some roman-numeral (i–v) combinations, some matching (1–4 → A–D).
- K-level must match the LO (K3 = application/calculation — verify every calculation with Python).
- CONCEPT DIVERSITY: within an LO, use many different concepts; no concept tag used by more than 3 questions of that LO; an LO with ≥ 10 questions needs ≥ 5 distinct concepts.
- Each question unambiguous; plausible distractors; no "all/none of the above".
- Avoid duplicating each other (no two questions with the same scenario + same ask).

## 3. Validate with Python before finishing
- per LO: count == total (existing converted + new)
- correct option is the (strict or tied) longest in ≤ 30% of your questions
- correct letters roughly even; len(correct) == selectCount; letters exist
- concept rules above
- unique ids
- similarity vs official: for each question, max share of word 6-grams (stem+options) found in any official question (exam_*.json) must be < 0.20 — rewrite offenders
Output file: /home/claude/ctfl/data/public/questions/bank_<NAME>.json (one JSON array). Build it with a Python script in your scratchpad (list of dicts → json.dump, ensure_ascii=False).
Final reply: short table per LO (total, concepts), longest-correct %, letter distribution, issues.
