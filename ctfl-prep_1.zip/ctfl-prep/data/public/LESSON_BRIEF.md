# Brief: chapter lessons + Check-yourself questions (PUBLIC, original content)

Read /home/claude/ctfl/data/SCHEMA.md and /home/claude/ctfl/data/shared/syllabus.json first.
Do NOT use any browser tools and do NOT copy ISTQB text: write everything in your own words from your knowledge of CTFL v4.0.1. You may read the original practice questions in /home/claude/istqb/data/gen_ch*.json and notes in /home/claude/istqb/data/notes_ch*.md (our own earlier material) for consistency, but write fresh, tighter content. Never reuse or paraphrase official sample-exam questions (/home/claude/istqb/data/exam_*.json) — check you don't.

## Lessons — /home/claude/ctfl/data/public/lessons/<code>.md (one per leaf topic you own)
The owner wants FOCUSED, MINIMAL content — information must not be flooded just because it is cheap to generate.
- 150–300 words body (hard limits). Precise English, ISTQB v4.0.1 terminology, exam-relevant only.
- Structure: 1–2 sentence definition → `**Key points**` 3–5 bullets → `### Example` exactly ONE concrete example (skip only if truly impossible) → optional single small table if it replaces prose.
- No history, motivation filler, repeated summaries, "In conclusion".
- Front matter per SCHEMA.md. Add `trick:` (rule / trap / check, each one line) ONLY if a real, commonly tested exam trap exists for that LO; otherwise omit it.
- `readMinutes` = ceil(words / 200).

## Check-yourself questions — /home/claude/ctfl/data/public/questions/lesson_<NAME>.json
- Exactly 3 questions per leaf topic, usage "lesson", source "original", visibility "public", ids `L-<code>-01..03`.
- Each tests that topic only, at the topic's K-level (K3 → application/calculation; verify calculations with Python).
- Each of the 3 has a DIFFERENT `concept` tag (kebab-case, descriptive, e.g. `principles-tests-wear-out`, `error-vs-defect-vs-failure`).
- 4 options a–d (Select ONE). Exactly one correct. Plausible distractors.
- OPTION LENGTH RULE: options of similar length; the correct option must NOT be the longest in more than 30% of your questions (count by characters). Validate with Python and rewrite until true.
- Spread correct letters evenly.
- `rationale` object: one short sentence per option (why right / why wrong).
- Stem without "Select ONE option." suffix (the UI adds it).

## Validate (Python) and report
Word counts per lesson (all 150–300), 3 questions per topic, unique concepts per topic, correct-is-longest %, correct-letter distribution, JSON valid. Final reply: short summary table.

## Cheat sheet (only if your task says you own a chapter's cheat sheet)
File: /home/claude/ctfl/data/public/cheatsheets/<chapter>.md — follow the exact format of cheatsheets/1.md (read it).
- MUST-KNOW items only: the shortest notes without which the chapter would be incomplete (lists, chains, formulas, distinctions the exam tests directly — e.g. test levels, review roles/types, technique coverage formulas, estimation formulas, risk level = likelihood × impact, defect report contents, tool categories).
- Terse: one `**Label:** content` line per item, items separated by ` · `. No explanations, no examples. Fits one screen (ch4/ch5 may have ~12–14 lines, ch6 ~4).
